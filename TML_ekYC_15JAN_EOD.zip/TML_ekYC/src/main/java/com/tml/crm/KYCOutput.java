
package com.tml.crm;


import javax.xml.bind.annotation.XmlNsForm;
import javax.xml.bind.annotation.XmlSchema;
import javax.xml.bind.annotation.XmlType;

import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.Style;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.util.ArrayList;
import java.util.List;

import javax.jws.soap.SOAPBinding;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;


@XmlType(name = "KYCOutput", propOrder = {
		"statusMsg","requestId","statusCode","result",
		"docType","api1_Status","api2_Status","api3_Status","api4_Status","api5_Status",

}) 
//@SOAPBinding(style=Style.DOCUMENT)

@XmlRootElement(name = "KYCOutput" ,namespace="http://schemas.xmlsoap.org/soap/envelope/")


/*//@XmlRootElement
@XmlRootElement(namespace="http://www.example.com/FOO")*/
public class KYCOutput {
	
	protected String statusMsg;
	protected String requestId;
	//@XmlElement(name="status-code")
	protected String statusCode;
	
	protected String docType;
	protected String api1_Status;
	protected String api2_Status;
	protected String api3_Status;
	protected String api4_Status;
	protected String api5_Status;
	
	
	@XmlElement(name="result")
	@JsonFormat(with = JsonFormat.Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY)
	protected List<ResultObj> result ;

	public String getDocType() {
		return docType;
	}

	public void setDocType(String docType) {
		this.docType = docType;
	}

	public String getApi1_Status() {
		return api1_Status;
	}

	public void setApi1_Status(String api1_Status) {
		this.api1_Status = api1_Status;
	}

	public String getApi2_Status() {
		return api2_Status;
	}

	public void setApi2_Status(String api2_Status) {
		this.api2_Status = api2_Status;
	}

	public String getApi3_Status() {
		return api3_Status;
	}

	public void setApi3_Status(String api3_Status) {
		this.api3_Status = api3_Status;
	}

	public String getApi4_Status() {
		return api4_Status;
	}

	public void setApi4_Status(String api4_Status) {
		this.api4_Status = api4_Status;
	}

	public String getApi5_Status() {
		return api5_Status;
	}

	public void setApi5_Status(String api5_Status) {
		this.api5_Status = api5_Status;
	}

	public String getStatusMsg() {
		return statusMsg;
	}

	public void setStatusMsg(String statusMsg) {
		this.statusMsg = statusMsg;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	@XmlElement(name="status-code")
	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	
	
	
	/* public List<ResultObj> getResult() {
			
			if (result == null) {
				result = new ArrayList<ResultObj>();
	        }
	        return this.result;
		}
	 

	public void setResult(List<ResultObj> result) {
		this.result = result;
	}*/
	
	

}
