package com.tml.crm;

import javax.xml.bind.annotation.XmlType;


import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;


@XmlType(name = "KYCOutput", propOrder = {
		"statusMsg","requestId","statusCode","result"

}) 
public class KYCOutput {
	
	protected String statusMsg;
	protected String requestId;
	protected String statusCode;
	protected List<ResultObj> result ;

	public String getStatusMsg() {
		return statusMsg;
	}

	public void setStatusMsg(String statusMsg) {
		this.statusMsg = statusMsg;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	
	
	 public List<ResultObj> getResult() {
			
			if (result == null) {
				result = new ArrayList<ResultObj>();
	        }
	        return this.result;
		}
	 

	public void setResult(List<ResultObj> result) {
		this.result = result;
	}
	
	

}
