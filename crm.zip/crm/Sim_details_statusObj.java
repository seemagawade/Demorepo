package com.tml.crm;



import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Sim_details_statusObj", propOrder = {
    "otp_validated",
    "provider"    
})

public class Sim_details_statusObj {

	
	String otp_validated;
	String provider;
	public String getOtp_validated() {
		return otp_validated;
	}
	public void setOtp_validated(String otp_validated) {
		this.otp_validated = otp_validated;
	}
	public String getProvider() {
		return provider;
	}
	public void setProvider(String provider) {
		this.provider = provider;
	}
}
