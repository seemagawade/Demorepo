package org.mycompany;

public class b_listObj {

}
