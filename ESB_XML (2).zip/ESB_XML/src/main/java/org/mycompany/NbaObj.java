package org.mycompany;

public class NbaObj {

}
