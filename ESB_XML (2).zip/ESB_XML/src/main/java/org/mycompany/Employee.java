package org.mycompany;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.fasterxml.jackson.annotation.JsonFormat;



//import crm.tml.org.Response;


@XmlRootElement(namespace = "http://schemas.xmlsoap.org/soap/envelope/", name = "employeeResponse")


//@XmlRootElement(name = "Employee")


@XmlType(propOrder = {
		"empName","empId", "result"	,"Val","Id"

}) 
@XmlAccessorType(XmlAccessType.FIELD)
public class Employee {

	
	private String empName;
	
	@XmlElement(name="EmpId")
	private String empId;
	
	
	private String Val;
	
	
	
	private String Id;
	
	
	
	@XmlElementWrapper(name="EmpResponse")
	@XmlElement(name="result")
	//private List<EmpResponse> result;
//	private Collection<EmpResponse> result;

	@JsonFormat(with = JsonFormat.Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY)
	private List<EmpResponse> result;
	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	
	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	/*public List<EmpResponse> getResult() {
		return result;
	}*/
	
	 public List<EmpResponse> getResult() {
	        if (result == null) {
	        	result = new ArrayList<EmpResponse>();
	        }
	        return this.result;
	    }


	public void setResult(List<EmpResponse> result) {
		
		this.result = result;
	}

	public String getVal() {
		return Val;
	}

	public void setVal(String val) {
		Val = val;
	}

	public String getId() {
		return Id;
	}

	public void setId(String Id) {
		this.Id = Id;
	}


	
}