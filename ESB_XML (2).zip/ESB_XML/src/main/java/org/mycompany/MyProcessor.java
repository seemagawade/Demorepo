package org.mycompany;

import java.io.StringWriter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;


public class MyProcessor implements Processor {

	public void process(Exchange exchange) throws Exception {
		String employee = exchange.getIn().getBody(String.class);
		
		/*JAXBContext jaxbContext = JAXBContext.newInstance(employee);
        
        //Create Marshaller
        Marshaller jaxbMarshaller = jaxbContext.createMarshaller();

        //Required formatting??
        jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);

        //Print XML String to Console
        StringWriter sw = new StringWriter();
         
        //Write XML to StringWriter
        jaxbMarshaller.marshal(employee, sw);
         
        //Verify XML Content
        String xmlContent = sw.toString();
        System.out.println( xmlContent );
*/		
		
		exchange.getIn().setBody(employee);
	}

}
