package org.mycompany;

import java.util.ArrayList;
import java.util.List;

public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

/*		
		List<String> l1 = new ArrayList<>();
		
		l1.add("a");
		l1.add("a");
		l1.add("a");
		l1.add("a");
		
		System.out.println("List :" + l1.toString());
		
	
		*/
		
		
		
	}

}
