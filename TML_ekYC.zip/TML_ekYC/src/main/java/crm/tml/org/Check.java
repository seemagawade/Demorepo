
package crm.tml.org;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Check complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Check"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="pDOC_TYPE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="pROW_ID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="pCONSENT" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="pDOCUMENT_NO" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="pFULL_NAME" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="pDOB" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="pSERVICE_PROVIDER" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="pMOBILE_NO" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="pOTP" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="pLOGIN_ID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="pState" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="pDOI" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="pFileNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="pNameMatchFlag" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Check", propOrder = {
    "pdoctype",
    "prowid",
    "pconsent",
    "pdocumentno",
    "pfullname",
    "pdob",
    "pserviceprovider",
    "pmobileno",
    "potp",
    "ploginid",
    "pState",
    "pdoi",
    "pFileNo",
    "pNameMatchFlag"
})
public class Check {

    @XmlElement(name = "pDOC_TYPE")
    protected String pdoctype;
    @XmlElement(name = "pROW_ID")
    protected String prowid;
    @XmlElement(name = "pCONSENT")
    protected String pconsent;
    @XmlElement(name = "pDOCUMENT_NO")
    protected String pdocumentno;
    @XmlElement(name = "pFULL_NAME")
    protected String pfullname;
    @XmlElement(name = "pDOB")
    protected String pdob;
    @XmlElement(name = "pSERVICE_PROVIDER")
    protected String pserviceprovider;
    @XmlElement(name = "pMOBILE_NO")
    protected String pmobileno;
    @XmlElement(name = "pOTP")
    protected String potp;
    @XmlElement(name = "pLOGIN_ID")
    protected String ploginid;
    protected String pState;
    @XmlElement(name = "pDOI")
    protected String pdoi;
    protected String pFileNo;
    protected String pNameMatchFlag;

    /**
     * Gets the value of the pdoctype property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPDOCTYPE() {
        return pdoctype;
    }

    /**
     * Sets the value of the pdoctype property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPDOCTYPE(String value) {
        this.pdoctype = value;
    }

    /**
     * Gets the value of the prowid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPROWID() {
        return prowid;
    }

    /**
     * Sets the value of the prowid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPROWID(String value) {
        this.prowid = value;
    }

    /**
     * Gets the value of the pconsent property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPCONSENT() {
        return pconsent;
    }

    /**
     * Sets the value of the pconsent property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPCONSENT(String value) {
        this.pconsent = value;
    }

    /**
     * Gets the value of the pdocumentno property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPDOCUMENTNO() {
        return pdocumentno;
    }

    /**
     * Sets the value of the pdocumentno property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPDOCUMENTNO(String value) {
        this.pdocumentno = value;
    }

    /**
     * Gets the value of the pfullname property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPFULLNAME() {
        return pfullname;
    }

    /**
     * Sets the value of the pfullname property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPFULLNAME(String value) {
        this.pfullname = value;
    }

    /**
     * Gets the value of the pdob property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPDOB() {
        return pdob;
    }

    /**
     * Sets the value of the pdob property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPDOB(String value) {
        this.pdob = value;
    }

    /**
     * Gets the value of the pserviceprovider property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPSERVICEPROVIDER() {
        return pserviceprovider;
    }

    /**
     * Sets the value of the pserviceprovider property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPSERVICEPROVIDER(String value) {
        this.pserviceprovider = value;
    }

    /**
     * Gets the value of the pmobileno property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPMOBILENO() {
        return pmobileno;
    }

    /**
     * Sets the value of the pmobileno property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPMOBILENO(String value) {
        this.pmobileno = value;
    }

    /**
     * Gets the value of the potp property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPOTP() {
        return potp;
    }

    /**
     * Sets the value of the potp property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPOTP(String value) {
        this.potp = value;
    }

    /**
     * Gets the value of the ploginid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPLOGINID() {
        return ploginid;
    }

    /**
     * Sets the value of the ploginid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPLOGINID(String value) {
        this.ploginid = value;
    }

    /**
     * Gets the value of the pState property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPState() {
        return pState;
    }

    /**
     * Sets the value of the pState property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPState(String value) {
        this.pState = value;
    }

    /**
     * Gets the value of the pdoi property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPDOI() {
        return pdoi;
    }

    /**
     * Sets the value of the pdoi property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPDOI(String value) {
        this.pdoi = value;
    }

    /**
     * Gets the value of the pFileNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPFileNo() {
        return pFileNo;
    }

    /**
     * Sets the value of the pFileNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPFileNo(String value) {
        this.pFileNo = value;
    }

    /**
     * Gets the value of the pNameMatchFlag property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPNameMatchFlag() {
        return pNameMatchFlag;
    }

    /**
     * Sets the value of the pNameMatchFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPNameMatchFlag(String value) {
        this.pNameMatchFlag = value;
    }

}
