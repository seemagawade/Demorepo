
package crm.tml.org;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the crm.tml.org package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _Check_QNAME = new QName("http://org.tml.crm/", "Check");
    private final static QName _KYCResponse_QNAME = new QName("http://org.tml.crm/", "KYCResponse");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: crm.tml.org
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link Check }
     * 
     */
    public Check createCheck() {
        return new Check();
    }

    /**
     * Create an instance of {@link KYCResponse }
     * 
     */
    public KYCResponse createKYCResponse() {
        return new KYCResponse();
    }

    /**
     * Create an instance of {@link CheckResponse }
     * 
     */
    public CheckResponse createCheckResponse() {
        return new CheckResponse();
    }

    /**
     * Create an instance of {@link PradrObj }
     * 
     */
    public PradrObj createPradrObj() {
        return new PradrObj();
    }

    /**
     * Create an instance of {@link ValidityObj }
     * 
     */
    public ValidityObj createValidityObj() {
        return new ValidityObj();
    }

    /**
     * Create an instance of {@link CovDetailsObj }
     * 
     */
    public CovDetailsObj createCovDetailsObj() {
        return new CovDetailsObj();
    }

    /**
     * Create an instance of {@link SimDetailsStatusObj }
     * 
     */
    public SimDetailsStatusObj createSimDetailsStatusObj() {
        return new SimDetailsStatusObj();
    }

    /**
     * Create an instance of {@link ContactObj }
     * 
     */
    public ContactObj createContactObj() {
        return new ContactObj();
    }

    /**
     * Create an instance of {@link DeviceObj }
     * 
     */
    public DeviceObj createDeviceObj() {
        return new DeviceObj();
    }

    /**
     * Create an instance of {@link HistoryObj }
     * 
     */
    public HistoryObj createHistoryObj() {
        return new HistoryObj();
    }

    /**
     * Create an instance of {@link IdentityObj }
     * 
     */
    public IdentityObj createIdentityObj() {
        return new IdentityObj();
    }

    /**
     * Create an instance of {@link ProfileObj }
     * 
     */
    public ProfileObj createProfileObj() {
        return new ProfileObj();
    }

    /**
     * Create an instance of {@link SimDetailsObj }
     * 
     */
    public SimDetailsObj createSimDetailsObj() {
        return new SimDetailsObj();
    }

    /**
     * Create an instance of {@link DateOfIssueObj }
     * 
     */
    public DateOfIssueObj createDateOfIssueObj() {
        return new DateOfIssueObj();
    }

    /**
     * Create an instance of {@link PassportNumberObj }
     * 
     */
    public PassportNumberObj createPassportNumberObj() {
        return new PassportNumberObj();
    }

    /**
     * Create an instance of {@link NamedetailsObj }
     * 
     */
    public NamedetailsObj createNamedetailsObj() {
        return new NamedetailsObj();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Check }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://org.tml.crm/", name = "Check")
    public JAXBElement<Check> createCheck(Check value) {
        return new JAXBElement<Check>(_Check_QNAME, Check.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link KYCResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://org.tml.crm/", name = "KYCResponse")
    public JAXBElement<KYCResponse> createKYCResponse(KYCResponse value) {
        return new JAXBElement<KYCResponse>(_KYCResponse_QNAME, KYCResponse.class, null, value);
    }

}
