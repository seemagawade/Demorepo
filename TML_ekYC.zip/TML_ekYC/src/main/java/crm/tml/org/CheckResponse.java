
package crm.tml.org;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for checkResponse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="checkResponse"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="status" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="name" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="canFlag" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="rc_body_type_desc" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="rc_chasi_no" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="rc_color" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="rc_cubic_cap" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="rc_eng_no" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="rc_f_name" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="rc_financer" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="rc_fit_upto" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="rc_fuel_desc" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="pradr" type="{http://org.tml.crm/}PradrObj" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="rc_gvw" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="rc_insurance_comp" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="rc_insurance_policy_no" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="rc_insurance_upto" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="rc_maker_desc" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="rc_maker_model" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="rc_manu_month_yr" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="rc_mobile_no" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="rc_no_cyl" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="rc_norms_desc" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="rc_owner_name" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="rc_permanent_address" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="rc_present_address" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="rc_registered_at" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="rc_regn_dt" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="rc_regn_no" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="rc_seat_cap" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="rc_sleeper_cap" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="rc_stand_cap" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="rc_status_as_on" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="rc_tax_upto" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="rc_unld_wt" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="rc_vch_catg" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="rc_vh_class_desc" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="rc_wheelbase" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="stautsMessage" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="issue_date" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="father_husband" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="img" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="blood_group" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="dob" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="validity" type="{http://org.tml.crm/}ValidityObj" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="cov_details" type="{http://org.tml.crm/}Cov_detailsObj" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="dl_number" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="address" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ps_lat_long" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="rln_name_v1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="rln_name_v2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="rln_name_v3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="part_no" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="rln_type" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="section_no" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="id" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="epic_no" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="rln_name" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="district" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="last_update" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="state" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ac_no" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="slno_inpart" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ps_name" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="pc_name" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="house_no" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="part_name" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="st_code" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="gender" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="age" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ac_name" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="name_v1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="name_v3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="name_v2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="aadhaarNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="approximateSubsidyAvailed" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="bankAccountNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="bankName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="consumerAddress" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="consumerContact" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="consumerEmail" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="consumerName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="consumerNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="distributorAddress" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="distributorCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="distributorName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="givenUpSubsidy" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="IFSCCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="lastBookingDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="subsidizedRefillConsumed" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="totalRefillConsumed" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="city_town" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="pin" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="message" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="sim_details_status" type="{http://org.tml.crm/}Sim_details_statusObj" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="contact" type="{http://org.tml.crm/}ContactObj" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="device" type="{http://org.tml.crm/}DeviceObj" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="history" type="{http://org.tml.crm/}HistoryObj" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="identity" type="{http://org.tml.crm/}IdentityObj" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="profile" type="{http://org.tml.crm/}ProfileObj" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="sim_details" type="{http://org.tml.crm/}Sim_detailsObj" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="applicationDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="dateOfIssue" type="{http://org.tml.crm/}DateOfIssueObj" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="passportNumber" type="{http://org.tml.crm/}PassportNumberObj" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="namedetails" type="{http://org.tml.crm/}NamedetailsObj" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="typeOfApplication" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="licType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="licNO" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="firmName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="store_name" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="contact_number" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="license_detail" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="score" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="result" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "checkResponse", propOrder = {
    "status",
    "name",
    "canFlag",
    "rcBodyTypeDesc",
    "rcChasiNo",
    "rcColor",
    "rcCubicCap",
    "rcEngNo",
    "rcFName",
    "rcFinancer",
    "rcFitUpto",
    "rcFuelDesc",
    "pradr",
    "rcGvw",
    "rcInsuranceComp",
    "rcInsurancePolicyNo",
    "rcInsuranceUpto",
    "rcMakerDesc",
    "rcMakerModel",
    "rcManuMonthYr",
    "rcMobileNo",
    "rcNoCyl",
    "rcNormsDesc",
    "rcOwnerName",
    "rcPermanentAddress",
    "rcPresentAddress",
    "rcRegisteredAt",
    "rcRegnDt",
    "rcRegnNo",
    "rcSeatCap",
    "rcSleeperCap",
    "rcStandCap",
    "rcStatusAsOn",
    "rcTaxUpto",
    "rcUnldWt",
    "rcVchCatg",
    "rcVhClassDesc",
    "rcWheelbase",
    "stautsMessage",
    "issueDate",
    "fatherHusband",
    "img",
    "bloodGroup",
    "dob",
    "validity",
    "covDetails",
    "dlNumber",
    "address",
    "psLatLong",
    "rlnNameV1",
    "rlnNameV2",
    "rlnNameV3",
    "partNo",
    "rlnType",
    "sectionNo",
    "id",
    "epicNo",
    "rlnName",
    "district",
    "lastUpdate",
    "state",
    "acNo",
    "slnoInpart",
    "psName",
    "pcName",
    "houseNo",
    "partName",
    "stCode",
    "gender",
    "age",
    "acName",
    "nameV1",
    "nameV3",
    "nameV2",
    "aadhaarNo",
    "approximateSubsidyAvailed",
    "bankAccountNo",
    "bankName",
    "consumerAddress",
    "consumerContact",
    "consumerEmail",
    "consumerName",
    "consumerNo",
    "distributorAddress",
    "distributorCode",
    "distributorName",
    "givenUpSubsidy",
    "ifscCode",
    "lastBookingDate",
    "subsidizedRefillConsumed",
    "totalRefillConsumed",
    "cityTown",
    "pin",
    "message",
    "simDetailsStatus",
    "contact",
    "device",
    "history",
    "identity",
    "profile",
    "simDetails",
    "applicationDate",
    "dateOfIssue",
    "passportNumber",
    "namedetails",
    "typeOfApplication",
    "licType",
    "licNO",
    "firmName",
    "storeName",
    "contactNumber",
    "licenseDetail",
    "score",
    "result"
})
public class CheckResponse {

    protected String status;
    protected String name;
    protected String canFlag;
    @XmlElement(name = "rc_body_type_desc")
    protected String rcBodyTypeDesc;
    @XmlElement(name = "rc_chasi_no")
    protected String rcChasiNo;
    @XmlElement(name = "rc_color")
    protected String rcColor;
    @XmlElement(name = "rc_cubic_cap")
    protected String rcCubicCap;
    @XmlElement(name = "rc_eng_no")
    protected String rcEngNo;
    @XmlElement(name = "rc_f_name")
    protected String rcFName;
    @XmlElement(name = "rc_financer")
    protected String rcFinancer;
    @XmlElement(name = "rc_fit_upto")
    protected String rcFitUpto;
    @XmlElement(name = "rc_fuel_desc")
    protected String rcFuelDesc;
    @XmlElement(nillable = true)
    protected List<PradrObj> pradr;
    @XmlElement(name = "rc_gvw")
    protected String rcGvw;
    @XmlElement(name = "rc_insurance_comp")
    protected String rcInsuranceComp;
    @XmlElement(name = "rc_insurance_policy_no")
    protected String rcInsurancePolicyNo;
    @XmlElement(name = "rc_insurance_upto")
    protected String rcInsuranceUpto;
    @XmlElement(name = "rc_maker_desc")
    protected String rcMakerDesc;
    @XmlElement(name = "rc_maker_model")
    protected String rcMakerModel;
    @XmlElement(name = "rc_manu_month_yr")
    protected String rcManuMonthYr;
    @XmlElement(name = "rc_mobile_no")
    protected String rcMobileNo;
    @XmlElement(name = "rc_no_cyl")
    protected String rcNoCyl;
    @XmlElement(name = "rc_norms_desc")
    protected String rcNormsDesc;
    @XmlElement(name = "rc_owner_name")
    protected String rcOwnerName;
    @XmlElement(name = "rc_permanent_address")
    protected String rcPermanentAddress;
    @XmlElement(name = "rc_present_address")
    protected String rcPresentAddress;
    @XmlElement(name = "rc_registered_at")
    protected String rcRegisteredAt;
    @XmlElement(name = "rc_regn_dt")
    protected String rcRegnDt;
    @XmlElement(name = "rc_regn_no")
    protected String rcRegnNo;
    @XmlElement(name = "rc_seat_cap")
    protected String rcSeatCap;
    @XmlElement(name = "rc_sleeper_cap")
    protected String rcSleeperCap;
    @XmlElement(name = "rc_stand_cap")
    protected String rcStandCap;
    @XmlElement(name = "rc_status_as_on")
    protected String rcStatusAsOn;
    @XmlElement(name = "rc_tax_upto")
    protected String rcTaxUpto;
    @XmlElement(name = "rc_unld_wt")
    protected String rcUnldWt;
    @XmlElement(name = "rc_vch_catg")
    protected String rcVchCatg;
    @XmlElement(name = "rc_vh_class_desc")
    protected String rcVhClassDesc;
    @XmlElement(name = "rc_wheelbase")
    protected String rcWheelbase;
    protected String stautsMessage;
    @XmlElement(name = "issue_date")
    protected String issueDate;
    @XmlElement(name = "father_husband")
    protected String fatherHusband;
    protected String img;
    @XmlElement(name = "blood_group")
    protected String bloodGroup;
    protected String dob;
    @XmlElement(nillable = true)
    protected List<ValidityObj> validity;
    @XmlElement(name = "cov_details", nillable = true)
    protected List<CovDetailsObj> covDetails;
    @XmlElement(name = "dl_number")
    protected String dlNumber;
    protected String address;
    @XmlElement(name = "ps_lat_long")
    protected String psLatLong;
    @XmlElement(name = "rln_name_v1")
    protected String rlnNameV1;
    @XmlElement(name = "rln_name_v2")
    protected String rlnNameV2;
    @XmlElement(name = "rln_name_v3")
    protected String rlnNameV3;
    @XmlElement(name = "part_no")
    protected String partNo;
    @XmlElement(name = "rln_type")
    protected String rlnType;
    @XmlElement(name = "section_no")
    protected String sectionNo;
    protected String id;
    @XmlElement(name = "epic_no")
    protected String epicNo;
    @XmlElement(name = "rln_name")
    protected String rlnName;
    protected String district;
    @XmlElement(name = "last_update")
    protected String lastUpdate;
    protected String state;
    @XmlElement(name = "ac_no")
    protected String acNo;
    @XmlElement(name = "slno_inpart")
    protected String slnoInpart;
    @XmlElement(name = "ps_name")
    protected String psName;
    @XmlElement(name = "pc_name")
    protected String pcName;
    @XmlElement(name = "house_no")
    protected String houseNo;
    @XmlElement(name = "part_name")
    protected String partName;
    @XmlElement(name = "st_code")
    protected String stCode;
    protected String gender;
    protected String age;
    @XmlElement(name = "ac_name")
    protected String acName;
    @XmlElement(name = "name_v1")
    protected String nameV1;
    @XmlElement(name = "name_v3")
    protected String nameV3;
    @XmlElement(name = "name_v2")
    protected String nameV2;
    protected String aadhaarNo;
    protected String approximateSubsidyAvailed;
    protected String bankAccountNo;
    protected String bankName;
    protected String consumerAddress;
    protected String consumerContact;
    protected String consumerEmail;
    protected String consumerName;
    protected String consumerNo;
    protected String distributorAddress;
    protected String distributorCode;
    protected String distributorName;
    protected String givenUpSubsidy;
    @XmlElement(name = "IFSCCode")
    protected String ifscCode;
    protected String lastBookingDate;
    protected String subsidizedRefillConsumed;
    protected String totalRefillConsumed;
    @XmlElement(name = "city_town")
    protected String cityTown;
    protected String pin;
    protected String message;
    @XmlElement(name = "sim_details_status", nillable = true)
    protected List<SimDetailsStatusObj> simDetailsStatus;
    @XmlElement(nillable = true)
    protected List<ContactObj> contact;
    @XmlElement(nillable = true)
    protected List<DeviceObj> device;
    @XmlElement(nillable = true)
    protected List<HistoryObj> history;
    @XmlElement(nillable = true)
    protected List<IdentityObj> identity;
    @XmlElement(nillable = true)
    protected List<ProfileObj> profile;
    @XmlElement(name = "sim_details", nillable = true)
    protected List<SimDetailsObj> simDetails;
    protected String applicationDate;
    @XmlElement(nillable = true)
    protected List<DateOfIssueObj> dateOfIssue;
    @XmlElement(nillable = true)
    protected List<PassportNumberObj> passportNumber;
    @XmlElement(nillable = true)
    protected List<NamedetailsObj> namedetails;
    protected String typeOfApplication;
    protected String licType;
    protected String licNO;
    protected String firmName;
    @XmlElement(name = "store_name")
    protected String storeName;
    @XmlElement(name = "contact_number")
    protected String contactNumber;
    @XmlElement(name = "license_detail")
    protected String licenseDetail;
    protected String score;
    protected String result;

    /**
     * Gets the value of the status property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatus(String value) {
        this.status = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the canFlag property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCanFlag() {
        return canFlag;
    }

    /**
     * Sets the value of the canFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCanFlag(String value) {
        this.canFlag = value;
    }

    /**
     * Gets the value of the rcBodyTypeDesc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRcBodyTypeDesc() {
        return rcBodyTypeDesc;
    }

    /**
     * Sets the value of the rcBodyTypeDesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRcBodyTypeDesc(String value) {
        this.rcBodyTypeDesc = value;
    }

    /**
     * Gets the value of the rcChasiNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRcChasiNo() {
        return rcChasiNo;
    }

    /**
     * Sets the value of the rcChasiNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRcChasiNo(String value) {
        this.rcChasiNo = value;
    }

    /**
     * Gets the value of the rcColor property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRcColor() {
        return rcColor;
    }

    /**
     * Sets the value of the rcColor property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRcColor(String value) {
        this.rcColor = value;
    }

    /**
     * Gets the value of the rcCubicCap property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRcCubicCap() {
        return rcCubicCap;
    }

    /**
     * Sets the value of the rcCubicCap property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRcCubicCap(String value) {
        this.rcCubicCap = value;
    }

    /**
     * Gets the value of the rcEngNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRcEngNo() {
        return rcEngNo;
    }

    /**
     * Sets the value of the rcEngNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRcEngNo(String value) {
        this.rcEngNo = value;
    }

    /**
     * Gets the value of the rcFName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRcFName() {
        return rcFName;
    }

    /**
     * Sets the value of the rcFName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRcFName(String value) {
        this.rcFName = value;
    }

    /**
     * Gets the value of the rcFinancer property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRcFinancer() {
        return rcFinancer;
    }

    /**
     * Sets the value of the rcFinancer property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRcFinancer(String value) {
        this.rcFinancer = value;
    }

    /**
     * Gets the value of the rcFitUpto property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRcFitUpto() {
        return rcFitUpto;
    }

    /**
     * Sets the value of the rcFitUpto property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRcFitUpto(String value) {
        this.rcFitUpto = value;
    }

    /**
     * Gets the value of the rcFuelDesc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRcFuelDesc() {
        return rcFuelDesc;
    }

    /**
     * Sets the value of the rcFuelDesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRcFuelDesc(String value) {
        this.rcFuelDesc = value;
    }

    /**
     * Gets the value of the pradr property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the pradr property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPradr().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PradrObj }
     * 
     * 
     */
    public List<PradrObj> getPradr() {
        if (pradr == null) {
            pradr = new ArrayList<PradrObj>();
        }
        return this.pradr;
    }

    /**
     * Gets the value of the rcGvw property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRcGvw() {
        return rcGvw;
    }

    /**
     * Sets the value of the rcGvw property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRcGvw(String value) {
        this.rcGvw = value;
    }

    /**
     * Gets the value of the rcInsuranceComp property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRcInsuranceComp() {
        return rcInsuranceComp;
    }

    /**
     * Sets the value of the rcInsuranceComp property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRcInsuranceComp(String value) {
        this.rcInsuranceComp = value;
    }

    /**
     * Gets the value of the rcInsurancePolicyNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRcInsurancePolicyNo() {
        return rcInsurancePolicyNo;
    }

    /**
     * Sets the value of the rcInsurancePolicyNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRcInsurancePolicyNo(String value) {
        this.rcInsurancePolicyNo = value;
    }

    /**
     * Gets the value of the rcInsuranceUpto property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRcInsuranceUpto() {
        return rcInsuranceUpto;
    }

    /**
     * Sets the value of the rcInsuranceUpto property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRcInsuranceUpto(String value) {
        this.rcInsuranceUpto = value;
    }

    /**
     * Gets the value of the rcMakerDesc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRcMakerDesc() {
        return rcMakerDesc;
    }

    /**
     * Sets the value of the rcMakerDesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRcMakerDesc(String value) {
        this.rcMakerDesc = value;
    }

    /**
     * Gets the value of the rcMakerModel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRcMakerModel() {
        return rcMakerModel;
    }

    /**
     * Sets the value of the rcMakerModel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRcMakerModel(String value) {
        this.rcMakerModel = value;
    }

    /**
     * Gets the value of the rcManuMonthYr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRcManuMonthYr() {
        return rcManuMonthYr;
    }

    /**
     * Sets the value of the rcManuMonthYr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRcManuMonthYr(String value) {
        this.rcManuMonthYr = value;
    }

    /**
     * Gets the value of the rcMobileNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRcMobileNo() {
        return rcMobileNo;
    }

    /**
     * Sets the value of the rcMobileNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRcMobileNo(String value) {
        this.rcMobileNo = value;
    }

    /**
     * Gets the value of the rcNoCyl property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRcNoCyl() {
        return rcNoCyl;
    }

    /**
     * Sets the value of the rcNoCyl property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRcNoCyl(String value) {
        this.rcNoCyl = value;
    }

    /**
     * Gets the value of the rcNormsDesc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRcNormsDesc() {
        return rcNormsDesc;
    }

    /**
     * Sets the value of the rcNormsDesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRcNormsDesc(String value) {
        this.rcNormsDesc = value;
    }

    /**
     * Gets the value of the rcOwnerName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRcOwnerName() {
        return rcOwnerName;
    }

    /**
     * Sets the value of the rcOwnerName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRcOwnerName(String value) {
        this.rcOwnerName = value;
    }

    /**
     * Gets the value of the rcPermanentAddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRcPermanentAddress() {
        return rcPermanentAddress;
    }

    /**
     * Sets the value of the rcPermanentAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRcPermanentAddress(String value) {
        this.rcPermanentAddress = value;
    }

    /**
     * Gets the value of the rcPresentAddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRcPresentAddress() {
        return rcPresentAddress;
    }

    /**
     * Sets the value of the rcPresentAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRcPresentAddress(String value) {
        this.rcPresentAddress = value;
    }

    /**
     * Gets the value of the rcRegisteredAt property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRcRegisteredAt() {
        return rcRegisteredAt;
    }

    /**
     * Sets the value of the rcRegisteredAt property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRcRegisteredAt(String value) {
        this.rcRegisteredAt = value;
    }

    /**
     * Gets the value of the rcRegnDt property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRcRegnDt() {
        return rcRegnDt;
    }

    /**
     * Sets the value of the rcRegnDt property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRcRegnDt(String value) {
        this.rcRegnDt = value;
    }

    /**
     * Gets the value of the rcRegnNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRcRegnNo() {
        return rcRegnNo;
    }

    /**
     * Sets the value of the rcRegnNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRcRegnNo(String value) {
        this.rcRegnNo = value;
    }

    /**
     * Gets the value of the rcSeatCap property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRcSeatCap() {
        return rcSeatCap;
    }

    /**
     * Sets the value of the rcSeatCap property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRcSeatCap(String value) {
        this.rcSeatCap = value;
    }

    /**
     * Gets the value of the rcSleeperCap property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRcSleeperCap() {
        return rcSleeperCap;
    }

    /**
     * Sets the value of the rcSleeperCap property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRcSleeperCap(String value) {
        this.rcSleeperCap = value;
    }

    /**
     * Gets the value of the rcStandCap property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRcStandCap() {
        return rcStandCap;
    }

    /**
     * Sets the value of the rcStandCap property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRcStandCap(String value) {
        this.rcStandCap = value;
    }

    /**
     * Gets the value of the rcStatusAsOn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRcStatusAsOn() {
        return rcStatusAsOn;
    }

    /**
     * Sets the value of the rcStatusAsOn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRcStatusAsOn(String value) {
        this.rcStatusAsOn = value;
    }

    /**
     * Gets the value of the rcTaxUpto property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRcTaxUpto() {
        return rcTaxUpto;
    }

    /**
     * Sets the value of the rcTaxUpto property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRcTaxUpto(String value) {
        this.rcTaxUpto = value;
    }

    /**
     * Gets the value of the rcUnldWt property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRcUnldWt() {
        return rcUnldWt;
    }

    /**
     * Sets the value of the rcUnldWt property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRcUnldWt(String value) {
        this.rcUnldWt = value;
    }

    /**
     * Gets the value of the rcVchCatg property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRcVchCatg() {
        return rcVchCatg;
    }

    /**
     * Sets the value of the rcVchCatg property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRcVchCatg(String value) {
        this.rcVchCatg = value;
    }

    /**
     * Gets the value of the rcVhClassDesc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRcVhClassDesc() {
        return rcVhClassDesc;
    }

    /**
     * Sets the value of the rcVhClassDesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRcVhClassDesc(String value) {
        this.rcVhClassDesc = value;
    }

    /**
     * Gets the value of the rcWheelbase property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRcWheelbase() {
        return rcWheelbase;
    }

    /**
     * Sets the value of the rcWheelbase property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRcWheelbase(String value) {
        this.rcWheelbase = value;
    }

    /**
     * Gets the value of the stautsMessage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStautsMessage() {
        return stautsMessage;
    }

    /**
     * Sets the value of the stautsMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStautsMessage(String value) {
        this.stautsMessage = value;
    }

    /**
     * Gets the value of the issueDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIssueDate() {
        return issueDate;
    }

    /**
     * Sets the value of the issueDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIssueDate(String value) {
        this.issueDate = value;
    }

    /**
     * Gets the value of the fatherHusband property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFatherHusband() {
        return fatherHusband;
    }

    /**
     * Sets the value of the fatherHusband property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFatherHusband(String value) {
        this.fatherHusband = value;
    }

    /**
     * Gets the value of the img property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getImg() {
        return img;
    }

    /**
     * Sets the value of the img property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setImg(String value) {
        this.img = value;
    }

    /**
     * Gets the value of the bloodGroup property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBloodGroup() {
        return bloodGroup;
    }

    /**
     * Sets the value of the bloodGroup property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBloodGroup(String value) {
        this.bloodGroup = value;
    }

    /**
     * Gets the value of the dob property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDob() {
        return dob;
    }

    /**
     * Sets the value of the dob property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDob(String value) {
        this.dob = value;
    }

    /**
     * Gets the value of the validity property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the validity property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getValidity().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ValidityObj }
     * 
     * 
     */
    public List<ValidityObj> getValidity() {
        if (validity == null) {
            validity = new ArrayList<ValidityObj>();
        }
        return this.validity;
    }

    /**
     * Gets the value of the covDetails property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the covDetails property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCovDetails().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CovDetailsObj }
     * 
     * 
     */
    public List<CovDetailsObj> getCovDetails() {
        if (covDetails == null) {
            covDetails = new ArrayList<CovDetailsObj>();
        }
        return this.covDetails;
    }

    /**
     * Gets the value of the dlNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDlNumber() {
        return dlNumber;
    }

    /**
     * Sets the value of the dlNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDlNumber(String value) {
        this.dlNumber = value;
    }

    /**
     * Gets the value of the address property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddress() {
        return address;
    }

    /**
     * Sets the value of the address property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddress(String value) {
        this.address = value;
    }

    /**
     * Gets the value of the psLatLong property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPsLatLong() {
        return psLatLong;
    }

    /**
     * Sets the value of the psLatLong property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPsLatLong(String value) {
        this.psLatLong = value;
    }

    /**
     * Gets the value of the rlnNameV1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRlnNameV1() {
        return rlnNameV1;
    }

    /**
     * Sets the value of the rlnNameV1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRlnNameV1(String value) {
        this.rlnNameV1 = value;
    }

    /**
     * Gets the value of the rlnNameV2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRlnNameV2() {
        return rlnNameV2;
    }

    /**
     * Sets the value of the rlnNameV2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRlnNameV2(String value) {
        this.rlnNameV2 = value;
    }

    /**
     * Gets the value of the rlnNameV3 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRlnNameV3() {
        return rlnNameV3;
    }

    /**
     * Sets the value of the rlnNameV3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRlnNameV3(String value) {
        this.rlnNameV3 = value;
    }

    /**
     * Gets the value of the partNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPartNo() {
        return partNo;
    }

    /**
     * Sets the value of the partNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPartNo(String value) {
        this.partNo = value;
    }

    /**
     * Gets the value of the rlnType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRlnType() {
        return rlnType;
    }

    /**
     * Sets the value of the rlnType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRlnType(String value) {
        this.rlnType = value;
    }

    /**
     * Gets the value of the sectionNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSectionNo() {
        return sectionNo;
    }

    /**
     * Sets the value of the sectionNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSectionNo(String value) {
        this.sectionNo = value;
    }

    /**
     * Gets the value of the id property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setId(String value) {
        this.id = value;
    }

    /**
     * Gets the value of the epicNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEpicNo() {
        return epicNo;
    }

    /**
     * Sets the value of the epicNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEpicNo(String value) {
        this.epicNo = value;
    }

    /**
     * Gets the value of the rlnName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRlnName() {
        return rlnName;
    }

    /**
     * Sets the value of the rlnName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRlnName(String value) {
        this.rlnName = value;
    }

    /**
     * Gets the value of the district property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDistrict() {
        return district;
    }

    /**
     * Sets the value of the district property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDistrict(String value) {
        this.district = value;
    }

    /**
     * Gets the value of the lastUpdate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastUpdate() {
        return lastUpdate;
    }

    /**
     * Sets the value of the lastUpdate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastUpdate(String value) {
        this.lastUpdate = value;
    }

    /**
     * Gets the value of the state property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getState() {
        return state;
    }

    /**
     * Sets the value of the state property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setState(String value) {
        this.state = value;
    }

    /**
     * Gets the value of the acNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAcNo() {
        return acNo;
    }

    /**
     * Sets the value of the acNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAcNo(String value) {
        this.acNo = value;
    }

    /**
     * Gets the value of the slnoInpart property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSlnoInpart() {
        return slnoInpart;
    }

    /**
     * Sets the value of the slnoInpart property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSlnoInpart(String value) {
        this.slnoInpart = value;
    }

    /**
     * Gets the value of the psName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPsName() {
        return psName;
    }

    /**
     * Sets the value of the psName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPsName(String value) {
        this.psName = value;
    }

    /**
     * Gets the value of the pcName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPcName() {
        return pcName;
    }

    /**
     * Sets the value of the pcName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPcName(String value) {
        this.pcName = value;
    }

    /**
     * Gets the value of the houseNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHouseNo() {
        return houseNo;
    }

    /**
     * Sets the value of the houseNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHouseNo(String value) {
        this.houseNo = value;
    }

    /**
     * Gets the value of the partName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPartName() {
        return partName;
    }

    /**
     * Sets the value of the partName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPartName(String value) {
        this.partName = value;
    }

    /**
     * Gets the value of the stCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStCode() {
        return stCode;
    }

    /**
     * Sets the value of the stCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStCode(String value) {
        this.stCode = value;
    }

    /**
     * Gets the value of the gender property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGender() {
        return gender;
    }

    /**
     * Sets the value of the gender property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGender(String value) {
        this.gender = value;
    }

    /**
     * Gets the value of the age property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAge() {
        return age;
    }

    /**
     * Sets the value of the age property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAge(String value) {
        this.age = value;
    }

    /**
     * Gets the value of the acName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAcName() {
        return acName;
    }

    /**
     * Sets the value of the acName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAcName(String value) {
        this.acName = value;
    }

    /**
     * Gets the value of the nameV1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNameV1() {
        return nameV1;
    }

    /**
     * Sets the value of the nameV1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNameV1(String value) {
        this.nameV1 = value;
    }

    /**
     * Gets the value of the nameV3 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNameV3() {
        return nameV3;
    }

    /**
     * Sets the value of the nameV3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNameV3(String value) {
        this.nameV3 = value;
    }

    /**
     * Gets the value of the nameV2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNameV2() {
        return nameV2;
    }

    /**
     * Sets the value of the nameV2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNameV2(String value) {
        this.nameV2 = value;
    }

    /**
     * Gets the value of the aadhaarNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAadhaarNo() {
        return aadhaarNo;
    }

    /**
     * Sets the value of the aadhaarNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAadhaarNo(String value) {
        this.aadhaarNo = value;
    }

    /**
     * Gets the value of the approximateSubsidyAvailed property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApproximateSubsidyAvailed() {
        return approximateSubsidyAvailed;
    }

    /**
     * Sets the value of the approximateSubsidyAvailed property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApproximateSubsidyAvailed(String value) {
        this.approximateSubsidyAvailed = value;
    }

    /**
     * Gets the value of the bankAccountNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBankAccountNo() {
        return bankAccountNo;
    }

    /**
     * Sets the value of the bankAccountNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBankAccountNo(String value) {
        this.bankAccountNo = value;
    }

    /**
     * Gets the value of the bankName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBankName() {
        return bankName;
    }

    /**
     * Sets the value of the bankName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBankName(String value) {
        this.bankName = value;
    }

    /**
     * Gets the value of the consumerAddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConsumerAddress() {
        return consumerAddress;
    }

    /**
     * Sets the value of the consumerAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConsumerAddress(String value) {
        this.consumerAddress = value;
    }

    /**
     * Gets the value of the consumerContact property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConsumerContact() {
        return consumerContact;
    }

    /**
     * Sets the value of the consumerContact property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConsumerContact(String value) {
        this.consumerContact = value;
    }

    /**
     * Gets the value of the consumerEmail property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConsumerEmail() {
        return consumerEmail;
    }

    /**
     * Sets the value of the consumerEmail property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConsumerEmail(String value) {
        this.consumerEmail = value;
    }

    /**
     * Gets the value of the consumerName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConsumerName() {
        return consumerName;
    }

    /**
     * Sets the value of the consumerName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConsumerName(String value) {
        this.consumerName = value;
    }

    /**
     * Gets the value of the consumerNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConsumerNo() {
        return consumerNo;
    }

    /**
     * Sets the value of the consumerNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConsumerNo(String value) {
        this.consumerNo = value;
    }

    /**
     * Gets the value of the distributorAddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDistributorAddress() {
        return distributorAddress;
    }

    /**
     * Sets the value of the distributorAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDistributorAddress(String value) {
        this.distributorAddress = value;
    }

    /**
     * Gets the value of the distributorCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDistributorCode() {
        return distributorCode;
    }

    /**
     * Sets the value of the distributorCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDistributorCode(String value) {
        this.distributorCode = value;
    }

    /**
     * Gets the value of the distributorName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDistributorName() {
        return distributorName;
    }

    /**
     * Sets the value of the distributorName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDistributorName(String value) {
        this.distributorName = value;
    }

    /**
     * Gets the value of the givenUpSubsidy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGivenUpSubsidy() {
        return givenUpSubsidy;
    }

    /**
     * Sets the value of the givenUpSubsidy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGivenUpSubsidy(String value) {
        this.givenUpSubsidy = value;
    }

    /**
     * Gets the value of the ifscCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIFSCCode() {
        return ifscCode;
    }

    /**
     * Sets the value of the ifscCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIFSCCode(String value) {
        this.ifscCode = value;
    }

    /**
     * Gets the value of the lastBookingDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastBookingDate() {
        return lastBookingDate;
    }

    /**
     * Sets the value of the lastBookingDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastBookingDate(String value) {
        this.lastBookingDate = value;
    }

    /**
     * Gets the value of the subsidizedRefillConsumed property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubsidizedRefillConsumed() {
        return subsidizedRefillConsumed;
    }

    /**
     * Sets the value of the subsidizedRefillConsumed property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubsidizedRefillConsumed(String value) {
        this.subsidizedRefillConsumed = value;
    }

    /**
     * Gets the value of the totalRefillConsumed property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTotalRefillConsumed() {
        return totalRefillConsumed;
    }

    /**
     * Sets the value of the totalRefillConsumed property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTotalRefillConsumed(String value) {
        this.totalRefillConsumed = value;
    }

    /**
     * Gets the value of the cityTown property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCityTown() {
        return cityTown;
    }

    /**
     * Sets the value of the cityTown property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCityTown(String value) {
        this.cityTown = value;
    }

    /**
     * Gets the value of the pin property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPin() {
        return pin;
    }

    /**
     * Sets the value of the pin property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPin(String value) {
        this.pin = value;
    }

    /**
     * Gets the value of the message property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMessage() {
        return message;
    }

    /**
     * Sets the value of the message property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMessage(String value) {
        this.message = value;
    }

    /**
     * Gets the value of the simDetailsStatus property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the simDetailsStatus property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSimDetailsStatus().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link SimDetailsStatusObj }
     * 
     * 
     */
    public List<SimDetailsStatusObj> getSimDetailsStatus() {
        if (simDetailsStatus == null) {
            simDetailsStatus = new ArrayList<SimDetailsStatusObj>();
        }
        return this.simDetailsStatus;
    }

    /**
     * Gets the value of the contact property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the contact property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getContact().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ContactObj }
     * 
     * 
     */
    public List<ContactObj> getContact() {
        if (contact == null) {
            contact = new ArrayList<ContactObj>();
        }
        return this.contact;
    }

    /**
     * Gets the value of the device property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the device property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDevice().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DeviceObj }
     * 
     * 
     */
    public List<DeviceObj> getDevice() {
        if (device == null) {
            device = new ArrayList<DeviceObj>();
        }
        return this.device;
    }

    /**
     * Gets the value of the history property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the history property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getHistory().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link HistoryObj }
     * 
     * 
     */
    public List<HistoryObj> getHistory() {
        if (history == null) {
            history = new ArrayList<HistoryObj>();
        }
        return this.history;
    }

    /**
     * Gets the value of the identity property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the identity property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getIdentity().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link IdentityObj }
     * 
     * 
     */
    public List<IdentityObj> getIdentity() {
        if (identity == null) {
            identity = new ArrayList<IdentityObj>();
        }
        return this.identity;
    }

    /**
     * Gets the value of the profile property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the profile property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getProfile().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ProfileObj }
     * 
     * 
     */
    public List<ProfileObj> getProfile() {
        if (profile == null) {
            profile = new ArrayList<ProfileObj>();
        }
        return this.profile;
    }

    /**
     * Gets the value of the simDetails property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the simDetails property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSimDetails().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link SimDetailsObj }
     * 
     * 
     */
    public List<SimDetailsObj> getSimDetails() {
        if (simDetails == null) {
            simDetails = new ArrayList<SimDetailsObj>();
        }
        return this.simDetails;
    }

    /**
     * Gets the value of the applicationDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApplicationDate() {
        return applicationDate;
    }

    /**
     * Sets the value of the applicationDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplicationDate(String value) {
        this.applicationDate = value;
    }

    /**
     * Gets the value of the dateOfIssue property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the dateOfIssue property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDateOfIssue().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DateOfIssueObj }
     * 
     * 
     */
    public List<DateOfIssueObj> getDateOfIssue() {
        if (dateOfIssue == null) {
            dateOfIssue = new ArrayList<DateOfIssueObj>();
        }
        return this.dateOfIssue;
    }

    /**
     * Gets the value of the passportNumber property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the passportNumber property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPassportNumber().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PassportNumberObj }
     * 
     * 
     */
    public List<PassportNumberObj> getPassportNumber() {
        if (passportNumber == null) {
            passportNumber = new ArrayList<PassportNumberObj>();
        }
        return this.passportNumber;
    }

    /**
     * Gets the value of the namedetails property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the namedetails property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getNamedetails().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link NamedetailsObj }
     * 
     * 
     */
    public List<NamedetailsObj> getNamedetails() {
        if (namedetails == null) {
            namedetails = new ArrayList<NamedetailsObj>();
        }
        return this.namedetails;
    }

    /**
     * Gets the value of the typeOfApplication property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTypeOfApplication() {
        return typeOfApplication;
    }

    /**
     * Sets the value of the typeOfApplication property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTypeOfApplication(String value) {
        this.typeOfApplication = value;
    }

    /**
     * Gets the value of the licType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLicType() {
        return licType;
    }

    /**
     * Sets the value of the licType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLicType(String value) {
        this.licType = value;
    }

    /**
     * Gets the value of the licNO property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLicNO() {
        return licNO;
    }

    /**
     * Sets the value of the licNO property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLicNO(String value) {
        this.licNO = value;
    }

    /**
     * Gets the value of the firmName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFirmName() {
        return firmName;
    }

    /**
     * Sets the value of the firmName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFirmName(String value) {
        this.firmName = value;
    }

    /**
     * Gets the value of the storeName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStoreName() {
        return storeName;
    }

    /**
     * Sets the value of the storeName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStoreName(String value) {
        this.storeName = value;
    }

    /**
     * Gets the value of the contactNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContactNumber() {
        return contactNumber;
    }

    /**
     * Sets the value of the contactNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContactNumber(String value) {
        this.contactNumber = value;
    }

    /**
     * Gets the value of the licenseDetail property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLicenseDetail() {
        return licenseDetail;
    }

    /**
     * Sets the value of the licenseDetail property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLicenseDetail(String value) {
        this.licenseDetail = value;
    }

    /**
     * Gets the value of the score property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getScore() {
        return score;
    }

    /**
     * Sets the value of the score property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setScore(String value) {
        this.score = value;
    }

    /**
     * Gets the value of the result property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResult() {
        return result;
    }

    /**
     * Sets the value of the result property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResult(String value) {
        this.result = value;
    }

}
