package org.mycompany;


import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "HistoryObj", propOrder = {
    "amount",
    "payment_date",
    "payment_type"
})
public class HistoryObj {
	
	String amount;
	String payment_date;
	String payment_type;

}
