package org.mycompany;


import javax.jws.WebMethod;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.ws.RequestWrapper;
import javax.xml.ws.ResponseWrapper;

import org.mycompany.*;
@WebService(targetNamespace = "http://org.tml.crm/")
public interface KYCService {

	
	 @WebMethod
	    @RequestWrapper(localName = "Check", targetNamespace = "http://org.mycompany/", className = "org.mycompany.KYCInput")
	    @ResponseWrapper(localName = "checkResponse", targetNamespace = "http://org.mycompany/", className = "org.mycompany.KYCOutput")
	    @WebResult(name = "status", targetNamespace = "")
	//	public KYCOutput Check(KYCInput input);
	 
	 public KYCOutput Check(KYCOutput input);
}
