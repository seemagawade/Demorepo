package org.mycompany;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;



//import crm.tml.org.Response;


@XmlRootElement(namespace = "http://schemas.xmlsoap.org/soap/envelope/", name = "employeeResponse")


/*@XmlRootElement(name = "employee")*/


@XmlType(propOrder = {
		"empName","empId", "result"	

}) 
@XmlAccessorType(XmlAccessType.FIELD)
public class Employee {

	
	private String empName;
	private String empId;
	private List<EmpResponse> result;

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	/*public List<EmpResponse> getResult() {
		return result;
	}*/
	
	 public List<EmpResponse> getResult() {
	        if (result == null) {
	        	result = new ArrayList<EmpResponse>();
	        }
	        return this.result;
	    }


	public void setResult(List<EmpResponse> result) {
		
		this.result = result;
	}
	
	
}
