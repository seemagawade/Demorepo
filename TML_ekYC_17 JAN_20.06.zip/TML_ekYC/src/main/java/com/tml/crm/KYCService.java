package com.tml.crm;



import javax.jws.WebMethod;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.xml.ws.RequestWrapper;
import javax.xml.ws.ResponseWrapper;


@WebService(targetNamespace = "http://com.tml.crm/")
//@SOAPBinding(style = SOAPBinding.Style.RPC)
public interface KYCService {

	
	 @WebMethod
	    @RequestWrapper(localName = "", targetNamespace = "http://com.tml.crm/", className = "com.tml.crm.KYCInput")
	    @ResponseWrapper(localName = "", targetNamespace = "http://com.tml.crm/", className = "com.tml.crm.KYCInputResponse")
	    @WebResult(name = "status", targetNamespace = "")
		public KYCInputResponse KYCInput(KYCInput input);
}
