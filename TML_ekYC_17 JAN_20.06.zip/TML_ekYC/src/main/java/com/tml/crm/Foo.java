package com.tml.crm;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "Foo" )
public class Foo {

	String bar;

	public String getBar() {
		return bar;
	}

	public void setBar(String bar) {
		this.bar = bar;
	}
}
