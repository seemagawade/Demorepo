package com.tml.crm;

import java.io.IOException;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.soap.AttachmentPart;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.Name;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;
import javax.xml.transform.stream.StreamSource;
import java.io.ByteArrayInputStream;


public class Demo {

	
	public static void main(String args[]) throws SOAPException, IOException, JAXBException
	{
		// MessageFactory mf = MessageFactory.newInstance();
		// createMessage(mf);
		 
		// create();
		
		    MessageFactory mf = MessageFactory.newInstance();
		    SOAPMessage message = mf.createMessage();
		    SOAPBody body = message.getSOAPBody();

		    Foo foo = new Foo();
		    foo.setBar("Hello World");

		    JAXBContext jc = JAXBContext.newInstance(Foo.class);
		    Marshaller marshaller = jc.createMarshaller();
		    marshaller.marshal(foo, body);

		    message.saveChanges();
		    message.writeTo(System.out);
	}
	
	public static SOAPMessage createMessage(MessageFactory mf) throws SOAPException, IOException {
	    SOAPMessage msg = mf.createMessage();
	    SOAPEnvelope envelope = msg.getSOAPPart().getEnvelope();
	    Name name = envelope.createName("hello", "ex", "http://example.com");
	    envelope.getBody().addChildElement(name).addTextNode("THERE!");

	    String s = "<root><hello>THERE!</hello></root>";

	    AttachmentPart ap = msg.createAttachmentPart(
	            new StreamSource(new ByteArrayInputStream(s.getBytes())),
	            "text/xml"
	    );
	    msg.addAttachmentPart(ap);
	    msg.saveChanges();
       System.out.println(msg.getSOAPPart());
       System.out.println(msg.getSOAPBody());
       System.out.println(msg.getSOAPHeader());
	    return msg;
	}
	
	public static SOAPMessage create() throws SOAPException {
	    MessageFactory messageFactory = MessageFactory.newInstance();
	    SOAPMessage message = messageFactory.createMessage();
	    SOAPPart soapPart = message.getSOAPPart();

	    SOAPEnvelope envelope = soapPart.getEnvelope();
	    envelope.addNamespaceDeclaration("codecentric", "https://www.codecentric.de");

	    SOAPBody envelopeBody = envelope.getBody();
	    SOAPElement soapBodyElem = envelopeBody.addChildElement("location", "codecentric");

	    SOAPElement place = soapBodyElem.addChildElement("place", "codecentric");
	    place.addTextNode("Berlin");

	    MimeHeaders headers = message.getMimeHeaders();
	    headers.addHeader("SOAPAction", "https://www.codecentric.de/location");

	    message.saveChanges();
	    System.out.println(message);
	    return message;
	}
}
