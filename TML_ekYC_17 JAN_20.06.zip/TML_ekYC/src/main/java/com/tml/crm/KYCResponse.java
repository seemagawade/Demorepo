package com.tml.crm;

import org.apache.camel.Exchange;

public class KYCResponse {

	KYCInputResponse output;

	public KYCResponse() {
		this.output=new KYCInputResponse();
	}
	
	public void response(final Exchange exchange) throws Exception {
        this.output.setStatusMsg("SUCCESS");
        exchange.getOut().setBody((Object)this.output);
    }
	
}
