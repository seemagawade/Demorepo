package org.mycompany;

import java.util.HashMap;
import java.util.LinkedHashMap;

public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		HashMap<String, String> map1 = new HashMap<>();
		HashMap<String, String> map2 = new LinkedHashMap<>();
		map1.put("England", "London");
		map1.put("Germany", "Berlin");
		
		 String obj = map1.remove("England");
		 map1.put("name1ist", obj);
		 
		 System.out.println(map1);
		 
		 
		 map1.put("namevalue", map1.get("name1ist"));
		 map1.remove("name1ist");
		 
		 System.out.println(map1);
	}

	
	
}
