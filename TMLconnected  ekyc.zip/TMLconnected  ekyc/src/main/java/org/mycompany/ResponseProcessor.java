package org.mycompany;

import java.util.HashMap;
import java.util.LinkedHashMap;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.Processor;

import org.apache.cxf.message.MessageContentsList;
import org.apache.log4j.Logger;

import com.fasterxml.jackson.databind.ObjectMapper;

public class ResponseProcessor implements Processor {

	Logger log = Logger.getLogger(ResponseProcessor.class);

	@Override
	public void process(Exchange exchange) throws Exception {
		try {
			Message inMessage = exchange.getIn();

			//System.out.println("**************IN process*********");
			String api1_status = null;
			String api2_status = null;
			String api3_status = null;
			String api4_status = null, api5_status = null, vMsg = null;
			String reqId = (String) inMessage.getHeader("requestId", String.class);
			String statusCode = (String) inMessage.getHeader("statusCode", String.class);

			api1_status = (String) inMessage.getHeader("statusApi1", String.class);
			api2_status = (String) inMessage.getHeader("statusApi2", String.class);

			String doc_type = (String) inMessage.getHeader("pDOC_TYPE", String.class);
			String jsonString = null;
			String tentResponse = null;

			//System.out.println("api1_status---" + api1_status);
			//System.out.println("doc_type----" + doc_type);
			//System.out.println("statusCode----" + statusCode);
			ObjectMapper objectMapper = new ObjectMapper();
			if (statusCode.equals("101")) {

				//System.out.println("**************IN process******** 101 both API");
				HashMap<String, String> map1 = new HashMap<>();
				map1 = (HashMap<String, String>) inMessage.getHeader("responseBody");

				HashMap<String, String> map2 = new HashMap<>();
				map2 = (HashMap<String, String>) inMessage.getHeader("resultscore");

				//System.out.println("rcBody : " + map2);

				map1.putAll(map2);

				//System.out.println("Combine Body : " + map1);

				jsonString = objectMapper.writeValueAsString(map1);

				//System.out.println("JsonSTring : " + jsonString);

				tentResponse = "{\"requestId\":\"" + reqId + "\",\"result\":" + jsonString + ",\"docType\":\""
						+ doc_type + "\",\"api1_Status\":\"" + api1_status + "\",\"api2_Status\":\"" + api2_status
						+ "\",\"api3_Status\":\"" + api3_status + "\",\"api4_Status\":\"" + api4_status
						+ "\",\"api5_Status\":\"" + api5_status + "\" ,\"statusCode\":\"" + statusCode + "\"}";

			} else if (statusCode.equals("102")) {

				//System.out.println("**************IN ResponseProcessor******* 102*");

				if (api1_status.equals("validated")) {
					
					//System.out.println("**************IN process******** 101 1st api and 102 2nd api");
					HashMap<String, String> map1 = new HashMap<>();
					map1 = (HashMap<String, String>) inMessage.getHeader("responseBody");

					jsonString = objectMapper.writeValueAsString(map1);

					tentResponse = "{\"requestId\":\"" + reqId + "\",\"result\":" + jsonString + ",\"docType\":\""
							+ doc_type + "\",\"api1_Status\":\"" + api1_status + "\",\"api2_Status\":\"" + api2_status
							+ "\",\"api3_Status\":\"" + api3_status + "\",\"api4_Status\":\"" + api4_status
							+ "\",\"api5_Status\":\"" + api5_status + "\" ,\"statusCode\":\"" + statusCode + "\"}";

				} else {

					//System.out.println("**************IN process******** 102 1st api");
					tentResponse = "{\"requestId\":\"" + reqId + "\",\"docType\":\"" + doc_type
							+ "\",\"api1_Status\":\"" + api1_status + "\",\"api2_Status\":\"" + api2_status
							+ "\",\"api3_Status\":\"" + api3_status + "\",\"api4_Status\":\"" + api4_status
							+ "\",\"api5_Status\":\"" + api5_status + "\" ,\"statusCode\":\"" + statusCode + "\"}";
				}

			} else {

				//System.out.println("**************IN process********other than 101  and 102*");

				String vstatusMsg = (String) inMessage.getHeader("resultScore", String.class);

				vMsg = (String) inMessage.getHeader("Stsmsg", String.class);

				if (api1_status.equals("validated")) {
					//System.out.println("**************IN process********other than 101  and 102*  validated 1st API");
					HashMap<String, String> map1 = new HashMap<>();
					map1 = (HashMap<String, String>) inMessage.getHeader("responseBody");

					//System.out.println("**************IN process********other than 101  and 102*  reading response of 1st API");
					jsonString = objectMapper.writeValueAsString(map1);

					tentResponse = "{\"requestId\":\"" + reqId + "\",\"statusMsg\":\"" + vMsg + "\",\"result\":"
							+ jsonString + ",\"docType\":\"" + doc_type + "\",\"api1_Status\":\"" + api1_status
							+ "\",\"api2_Status\":\"" + api2_status + "\",\"api3_Status\":\"" + api3_status
							+ "\",\"api4_Status\":\"" + api4_status + "\",\"api5_Status\":\"" + api5_status
							+ "\" ,\"statusCode\":\"" + statusCode + "\"}";
				} else {
					System.out.println("**************IN process********other than 101  and 102*  failed 1st API");
					tentResponse = "{\"requestId\":\"" + reqId + "\",\"statusMsg\":\"" + vMsg + "\",\"docType\":\""
							+ doc_type + "\",\"api1_Status\":\"" + api1_status + "\",\"api2_Status\":\"" + api2_status
							+ "\",\"api3_Status\":\"" + api3_status + "\",\"api4_Status\":\"" + api4_status
							+ "\",\"api5_Status\":\"" + api5_status + "\" ,\"statusCode\":\"" + statusCode + "\"}";
				}
				
				
			

			}

			inMessage.setHeader(Exchange.CONTENT_TYPE, "application/json");
			MessageContentsList req = new MessageContentsList();
			req.add(tentResponse);
			//System.out.println("bodyPara" + req);
			inMessage.setBody(req);

		} catch (Exception e) {
			log.error("Exception in process()", e);
		}

	}

	public void validationProcess(Exchange exchange) throws Exception {
		try {
			Message inMessage = exchange.getIn();

			//System.out.println("**************IN validationProcess*********");
			String api1_status = null;
			String api2_status = null;
			String api3_status = null;
			String api4_status = null, api5_status = null, statusCode = null, reqId = null, vMsg = null,
					doc_type = null;
			String jsonString = null;
			String tentResponse = null;

			doc_type = (String) inMessage.getHeader("pDOC_TYPE", String.class);
			vMsg = (String) inMessage.getHeader("Stsmsg", String.class);

			//System.out.println("doc_type----" + doc_type);
			//System.out.println("vMsg----" + vMsg);

			tentResponse = "{\"requestId\":\"" + reqId + "\",\"statusMsg\":\"" + vMsg + "\",\"docType\":\"" + doc_type
					+ "\",\"api1_Status\":\"" + api1_status + "\",\"api2_Status\":\"" + api2_status
					+ "\",\"api3_Status\":\"" + api3_status + "\",\"api4_Status\":\"" + api4_status
					+ "\",\"api5_Status\":\"" + api5_status + "\" ,\"statusCode\":\"" + statusCode + "\"}";

			inMessage.setHeader(Exchange.CONTENT_TYPE, "application/json");
			MessageContentsList req = new MessageContentsList();
			req.add(tentResponse);
			//System.out.println("bodyPara" + req);
			inMessage.setBody(req);

		} catch (Exception e) {
			log.error("Exception in process()", e);
		}

	}

	public void passportProcess(Exchange exchange) throws Exception {
		try {
			Message inMessage = exchange.getIn();

			//System.out.println("**************IN passportProcess*********");
			String api1_status = null;
			String api2_status = null;
			String api3_status = null;
			String api4_status = null, api5_status = null, vMsg = null;
			String reqId = (String) inMessage.getHeader("requestId", String.class);
			String statusCode = (String) inMessage.getHeader("statusCode", String.class);

			api1_status = (String) inMessage.getHeader("statusApi1", String.class);
			api2_status = (String) inMessage.getHeader("statusApi2", String.class);

			String doc_type = (String) inMessage.getHeader("pDOC_TYPE", String.class);
			String jsonString = null;
			String tentResponse = null;

			//System.out.println("api1_status---" + api1_status);
			//System.out.println("doc_type----" + doc_type);
			//System.out.println("statusCode----" + statusCode);
			ObjectMapper objectMapper = new ObjectMapper();
			if (statusCode.equals("101")) {

				//System.out.println("**************IN passportProcess********101*");
				HashMap<String, Object> map1 = new HashMap<>();

				HashMap<String, Object> map3 = new HashMap<>();
				map1 = (HashMap<String, Object>) inMessage.getHeader("responseBody");

				//System.out.println("MAP BEFORE CHNAGE" + map1);
				map1.put("name1ist", map1.get("name"));
				map1.remove("name");
				//System.out.println("MAP AFTER remove" + map1);

				map3.putAll(map1);
				jsonString = objectMapper.writeValueAsString(map3);

				//System.out.println("jsonString" + jsonString);

				tentResponse = "{\"requestId\":\"" + reqId + "\",\"result\":" + jsonString + ",\"docType\":\""
						+ doc_type + "\",\"api1_Status\":\"" + api1_status + "\",\"api2_Status\":\"" + api2_status
						+ "\",\"api3_Status\":\"" + api3_status + "\",\"api4_Status\":\"" + api4_status
						+ "\",\"api5_Status\":\"" + api5_status + "\" ,\"statusCode\":\"" + statusCode + "\"}";

			} else {

				tentResponse = "{\"requestId\":\"" + reqId + "\",\"docType\":\"" + doc_type + "\",\"api1_Status\":\""
						+ api1_status + "\",\"api2_Status\":\"" + api2_status + "\",\"api3_Status\":\"" + api3_status
						+ "\",\"api4_Status\":\"" + api4_status + "\",\"api5_Status\":\"" + api5_status
						+ "\" ,\"statusCode\":\"" + statusCode + "\"}";

			}

			inMessage.setHeader(Exchange.CONTENT_TYPE, "application/json");
			MessageContentsList req = new MessageContentsList();
			req.add(tentResponse);
			//System.out.println("bodyPara" + req);
			inMessage.setBody(req);

		} catch (Exception e) {
			log.error("Exception in process()", e);
		}

	}

	public void SpecialCaseProcess(Exchange exchange) throws Exception {
		try {
			Message inMessage = exchange.getIn();

			//System.out.println("**************IN fssaiProcess*********");
			String api1_status = null;
			String api2_status = null;
			String api3_status = null;
			String api4_status = null, api5_status = null, vMsg = null ,vnon_transport=null,vtransport=null;
			String reqId = (String) inMessage.getHeader("requestId", String.class);
			String statusCode = (String) inMessage.getHeader("statusCode", String.class);

			api1_status = (String) inMessage.getHeader("statusApi1", String.class);
			api2_status = (String) inMessage.getHeader("statusApi2", String.class);

			String doc_type = (String) inMessage.getHeader("pDOC_TYPE", String.class);
			String jsonString = null;
			String tentResponse = null;

			//System.out.println("api1_status---" + api1_status);
			//System.out.println("doc_type----" + doc_type);
			//System.out.println("statusCode----" + statusCode);
			ObjectMapper objectMapper = new ObjectMapper();
			if (statusCode.equals("101")) {

				//System.out.println("**************IN fssaiProcess********101*");
				HashMap<String, Object> map1 = new HashMap<>();
				map1 = (HashMap<String, Object>) inMessage.getHeader("responseBody");

				HashMap<String, Object> map2 = new HashMap<>();
				
				map2 = (HashMap<String, Object>) inMessage.getHeader("resultscore");

				
				HashMap<String, Object> map3 = new HashMap<>();
				
				//System.out.println("fssaiProcess   map1 : " + map1);

				if (doc_type.equals("FSSAI")) {
					map1.put("status", map1.get("Status"));
					map1.remove("Status");

					map1.put("licType", map1.get("LicType"));
					map1.remove("LicType");

					map1.put("licNO", map1.get("LicNO"));
					map1.remove("LicNO");

					map1.put("firmName", map1.get("FirmName"));
					map1.remove("FirmName");

					map1.put("address", map1.get("Address"));
					map1.remove("Address");
				} else if (doc_type.equals("LPG")) {
					map1.put("aadhaarNo", map1.get("AadhaarNo"));
					map1.remove("AadhaarNo");

					map1.put("approximateSubsidyAvailed", map1.get("ApproximateSubsidyAvailed"));
					map1.remove("ApproximateSubsidyAvailed");

					map1.put("bankAccountNo", map1.get("BankAccountNo"));
					map1.remove("BankAccountNo");

					map1.put("bankName", map1.get("BankName"));
					map1.remove("BankName");

					map1.put("consumerAddress", map1.get("ConsumerAddress"));
					map1.remove("ConsumerAddress");
					map1.put("consumerEmail", map1.get("ConsumerEmail"));
					map1.remove("ConsumerEmail");
					map1.put("consumerContact", map1.get("ConsumerContact"));
					map1.remove("ConsumerContact");
					map1.put("consumerName", map1.get("ConsumerName"));
					map1.remove("ConsumerName");
					map1.put("consumerNo", map1.get("ConsumerNo"));
					map1.remove("ConsumerNo");
					map1.put("distributorAddress", map1.get("DistributorAddress"));
					map1.remove("DistributorAddress");
					map1.put("distributorName", map1.get("DistributorName"));
					map1.remove("DistributorName");
					map1.put("givenUpSubsidy", map1.get("GivenUpSubsidy"));
					map1.remove("GivenUpSubsidy");
					map1.put("iFSCCode", map1.get("IFSCCode"));
					map1.remove("IFSCCode");
					map1.put("lastBookingDate", map1.get("LastBookingDate"));
					map1.remove("LastBookingDate");
					map1.put("subsidizedRefillConsumed", map1.get("SubsidizedRefillConsumed"));
					map1.remove("SubsidizedRefillConsumed");
					map1.put("totalRefillConsumed", map1.get("TotalRefillConsumed"));
					map1.remove("TotalRefillConsumed");

				}
				else if (doc_type.equals("DRIVING LICENSE")) {
					
					/*map1.put("father_husband", map1.get("father/husband"));
					map1.remove("father/husband");*/

					
					//map3 = (HashMap<String, Object>) inMessage.getHeader("validity_non_transport");
					
					/*vnon_transport = (String) inMessage.getHeader("validity_non_transport", String.class);
					vtransport =(String) inMessage.getHeader("transport", String.class);
					
					System.out.println("validity_non_transport : " + vnon_transport);
					map3.put("non_transport",vnon_transport );
					map3.put("transport",vtransport );
				
					//map1.putAll(map3);
					System.out.println("map1 : " + map1);*/
					
					
				}

				//System.out.println("before combine Body : " + map1);

				map1.putAll(map2);

				//System.out.println("Combine Body : " + map1);

				jsonString = objectMapper.writeValueAsString(map1);

				//System.out.println("JsonSTring : " + jsonString);

				tentResponse = "{\"requestId\":\"" + reqId + "\",\"result\":" + jsonString + ",\"docType\":\""
						+ doc_type + "\",\"api1_Status\":\"" + api1_status + "\",\"api2_Status\":\"" + api2_status
						+ "\",\"api3_Status\":\"" + api3_status + "\",\"api4_Status\":\"" + api4_status
						+ "\",\"api5_Status\":\"" + api5_status + "\" ,\"statusCode\":\"" + statusCode + "\"}";

			}
			
			
			
			else {

				//System.out.println("**************IN fssaiProcess******* other cases*");

				vMsg = (String) inMessage.getHeader("Stsmsg", String.class);
				if (api1_status.equals("validated")) {
					//System.out.println("**************IN fssaiProcess******* other cases validated*");
					HashMap<String, Object> map1 = new HashMap<>();
					map1 = (HashMap<String, Object>) inMessage.getHeader("responseBody");

					//System.out.println("fssaiProcess   map1 : " + map1);

					if (doc_type.equals("FSSAI")) {
						map1.put("status", map1.get("Status"));
						map1.remove("Status");

						map1.put("licType", map1.get("LicType"));
						map1.remove("LicType");

						map1.put("licNO", map1.get("LicNO"));
						map1.remove("LicNO");

						map1.put("firmName", map1.get("FirmName"));
						map1.remove("FirmName");

						map1.put("address", map1.get("Address"));
						map1.remove("Address");
					} else if (doc_type.equals("LPG")) {
						map1.put("aadhaarNo", map1.get("AadhaarNo"));
						map1.remove("AadhaarNo");

						map1.put("approximateSubsidyAvailed", map1.get("ApproximateSubsidyAvailed"));
						map1.remove("ApproximateSubsidyAvailed");

						map1.put("bankAccountNo", map1.get("BankAccountNo"));
						map1.remove("BankAccountNo");

						map1.put("bankName", map1.get("BankName"));
						map1.remove("BankName");

						map1.put("consumerAddress", map1.get("ConsumerAddress"));
						map1.remove("ConsumerAddress");
						map1.put("consumerEmail", map1.get("ConsumerEmail"));
						map1.remove("ConsumerEmail");
						map1.put("consumerContact", map1.get("ConsumerContact"));
						map1.remove("ConsumerContact");
						map1.put("consumerName", map1.get("ConsumerName"));
						map1.remove("ConsumerName");
						map1.put("consumerNo", map1.get("ConsumerNo"));
						map1.remove("ConsumerNo");
						map1.put("distributorAddress", map1.get("DistributorAddress"));
						map1.remove("DistributorAddress");
						map1.put("distributorName", map1.get("DistributorName"));
						map1.remove("DistributorName");
						map1.put("givenUpSubsidy", map1.get("GivenUpSubsidy"));
						map1.remove("GivenUpSubsidy");
						map1.put("iFSCCode", map1.get("IFSCCode"));
						map1.remove("IFSCCode");
						map1.put("lastBookingDate", map1.get("LastBookingDate"));
						map1.remove("LastBookingDate");
						map1.put("subsidizedRefillConsumed", map1.get("SubsidizedRefillConsumed"));
						map1.remove("SubsidizedRefillConsumed");
						map1.put("totalRefillConsumed", map1.get("TotalRefillConsumed"));
						map1.remove("TotalRefillConsumed");

					}else if (doc_type.equals("DRIVING LICENSE")) {
						
						/*map1.put("father_husband", map1.get("father/husband"));
						map1.remove("father/husband");
						map1.put("non_transport", map1.get("non-transport"));
						map1.remove("non-transport");
						*/
						
					}

					//System.out.println("before combine Body : " + map1);

					

					//System.out.println("Combine Body : " + map1);

					jsonString = objectMapper.writeValueAsString(map1);

					tentResponse = "{\"requestId\":\"" + reqId + "\",\"statusMsg\":\"" + vMsg + "\",\"result\":"
							+ jsonString + ",\"docType\":\"" + doc_type + "\",\"api1_Status\":\"" + api1_status
							+ "\",\"api2_Status\":\"" + api2_status + "\",\"api3_Status\":\"" + api3_status
							+ "\",\"api4_Status\":\"" + api4_status + "\",\"api5_Status\":\"" + api5_status
							+ "\" ,\"statusCode\":\"" + statusCode + "\"}";

				} else {

					//System.out.println("**************IN fssaiProcess******* other cases failed*");
					tentResponse = "{\"requestId\":\"" + reqId + "\",\"statusMsg\":\"" + vMsg + "\",\"docType\":\""
							+ doc_type + "\",\"api1_Status\":\"" + api1_status + "\",\"api2_Status\":\"" + api2_status
							+ "\",\"api3_Status\":\"" + api3_status + "\",\"api4_Status\":\"" + api4_status
							+ "\",\"api5_Status\":\"" + api5_status + "\" ,\"statusCode\":\"" + statusCode + "\"}";
				}

			}

			inMessage.setHeader(Exchange.CONTENT_TYPE, "application/json");
			MessageContentsList req = new MessageContentsList();
			req.add(tentResponse);
			//System.out.println("bodyPara" + req);
			inMessage.setBody(req);

		} catch (Exception e) {
			log.error("Exception in process()", e);
		}

	}

	public void otpProcess(Exchange exchange) throws Exception {
		try {
			Message inMessage = exchange.getIn();

			//System.out.println("**************IN OTP Process*********");
			String api1_status = null;
			String api2_status = null;
			String api3_status = null;
			String api4_status = null, api5_status = null, statusCode = null, reqId = null, doc_type = null;
			String jsonString = null;
			String tentResponse = null;
			ObjectMapper objectMapper = new ObjectMapper();

			HashMap<String, String> map1 = new HashMap<>();
			map1 = (HashMap<String, String>) inMessage.getHeader("responseBody");

			doc_type = (String) inMessage.getHeader("pDOC_TYPE", String.class);
			jsonString = objectMapper.writeValueAsString(map1);
			//System.out.println("Json String" + jsonString);

			statusCode = (String) inMessage.getHeader("statusCode", String.class);
			api1_status = (String) inMessage.getHeader("statusApi1", String.class);
			api2_status = (String) inMessage.getHeader("statusApi2", String.class);
			api3_status = (String) inMessage.getHeader("statusApi3", String.class);
			reqId = (String) inMessage.getHeader("requestId", String.class);

			tentResponse = "{\"requestId\":\"" + reqId + "\",\"result\":" + jsonString + ",\"docType\":\"" + doc_type
					+ "\",\"api1_Status\":\"" + api1_status + "\",\"api2_Status\":\"" + api2_status
					+ "\",\"api3_Status\":\"" + api3_status + "\",\"api4_Status\":\"" + api4_status
					+ "\",\"api5_Status\":\"" + api5_status + "\" ,\"statusCode\":\"" + statusCode + "\"}";

			inMessage.setHeader(Exchange.CONTENT_TYPE, "application/json");
			MessageContentsList req = new MessageContentsList();
			req.add(tentResponse);
			//System.out.println("bodyPara" + req);
			inMessage.setBody(req);

		} catch (Exception e) {
			log.error("Exception in process()", e);
		}

	}

	public void otpStatusProcess(Exchange exchange) throws Exception {
		try {
			Message inMessage = exchange.getIn();

			//System.out.println("**************IN OTP STATUS Process*********");
			String api1_status = null;
			String api2_status = null;
			String api3_status = null;
			String api4_status = null, api5_status = null, statusCode = null, reqId = null, doc_type = null;
			String jsonString = null;
			String tentResponse = null;
			ObjectMapper objectMapper = new ObjectMapper();

			HashMap<String, String> map1 = new HashMap<>();
			map1 = (HashMap<String, String>) inMessage.getHeader("responseBody");

			HashMap<String, String> map2 = new HashMap<>();
			map2 = (HashMap<String, String>) inMessage.getHeader("otpDetailsBody");

			HashMap<String, String> map3 = new HashMap<>();
			map3 = (HashMap<String, String>) inMessage.getHeader("resultScore");

			map1.putAll(map2);
			map1.putAll(map3);

			doc_type = (String) inMessage.getHeader("pDOC_TYPE", String.class);
			jsonString = objectMapper.writeValueAsString(map1);
			//System.out.println("Json String" + jsonString);

			statusCode = (String) inMessage.getHeader("statusCode", String.class);
			api1_status = (String) inMessage.getHeader("statusApi1", String.class);
			api2_status = (String) inMessage.getHeader("statusApi2", String.class);
			api3_status = (String) inMessage.getHeader("statusApi3", String.class);
			reqId = (String) inMessage.getHeader("requestId", String.class);

			tentResponse = "{\"requestId\":\"" + reqId + "\",\"result\":" + jsonString + ",\"docType\":\"" + doc_type
					+ "\",\"api1_Status\":\"" + api1_status + "\",\"api2_Status\":\"" + api2_status
					+ "\",\"api3_Status\":\"" + api3_status + "\",\"api4_Status\":\"" + api4_status
					+ "\",\"api5_Status\":\"" + api5_status + "\" ,\"statusCode\":\"" + statusCode + "\"}";

			inMessage.setHeader(Exchange.CONTENT_TYPE, "application/json");
			MessageContentsList req = new MessageContentsList();
			req.add(tentResponse);
			//System.out.println("bodyPara" + req);
			inMessage.setBody(req);

		} catch (Exception e) {
			log.error("Exception in process()", e);
		}

	}

	public void exceptionProcess(Exchange exchange) throws Exception {
		try {
			Message inMessage = exchange.getIn();

			//System.out.println("**************Exception Process*********");
			String api1_status = null;
			String api2_status = null;
			String api3_status = null;
			String api4_status = null, api5_status = null, statusCode = null, reqId = null, doc_type = null;
			String jsonString = null;
			String tentResponse = null;

			ObjectMapper objectMapper = new ObjectMapper();

			HashMap<String, String> map1 = new HashMap<>();
			map1 = (HashMap<String, String>) inMessage.getHeader("responseBody");

			/*
			 * api1_status---validated doc_type----OTP DETAILS statusCode----400
			 */
			api1_status = (String) inMessage.getHeader("statusApi1", String.class);
			doc_type = (String) inMessage.getHeader("pDOC_TYPE", String.class);
			statusCode = (String) inMessage.getHeader("statusCode", String.class);

			jsonString = objectMapper.writeValueAsString(map1);

			reqId = (String) inMessage.getHeader("requestId", String.class);

			tentResponse = "{\"requestId\":\"" + reqId + "\",\"result\":" + jsonString + ",\"docType\":\"" + doc_type
					+ "\",\"api1_Status\":\"" + api1_status + "\",\"api2_Status\":\"" + api2_status
					+ "\",\"api3_Status\":\"" + api3_status + "\",\"api4_Status\":\"" + api4_status
					+ "\",\"api5_Status\":\"" + api5_status + "\" ,\"statusCode\":\"" + statusCode + "\"}";

			inMessage.setHeader(Exchange.CONTENT_TYPE, "application/json");
			MessageContentsList req = new MessageContentsList();
			req.add(tentResponse);
			//System.out.println("bodyPara" + req);
			inMessage.setBody(req);

		} catch (Exception e) {
			log.error("Exception in process()", e);
		}

	}

	public void otpNameException(Exchange exchange) throws Exception {
		try {
			Message inMessage = exchange.getIn();

			//System.out.println("**************Exception OTP Name Process*********");
			String api1_status = null;
			String api2_status = null;
			String api3_status = null;
			String api4_status = null, api5_status = null, statusCode = null, reqId = null, doc_type = null;
			String jsonString = null;
			String tentResponse = null;
			String statusMsg = null;

			ObjectMapper objectMapper = new ObjectMapper();

			HashMap<String, String> map1 = new HashMap<>();
			map1 = (HashMap<String, String>) inMessage.getHeader("responseBody");

			HashMap<String, String> map2 = new HashMap<>();
			map2 = (HashMap<String, String>) inMessage.getHeader("otpDetailsBody");

			map1.putAll(map2);

			jsonString = objectMapper.writeValueAsString(map1);
			//System.out.println("Json String" + jsonString);

			api1_status = (String) inMessage.getHeader("statusApi1", String.class);
			api2_status = (String) inMessage.getHeader("statusApi2", String.class);
			api3_status = (String) inMessage.getHeader("statusApi3", String.class);
			doc_type = (String) inMessage.getHeader("pDOC_TYPE", String.class);
			statusCode = (String) inMessage.getHeader("statusCode", String.class);
			reqId = (String) inMessage.getHeader("requestId", String.class);

			tentResponse = "{\"requestId\":\"" + reqId + "\",\"result\":" + jsonString + ",\"docType\":\"" + doc_type
					+ "\",\"api1_Status\":\"" + api1_status + "\",\"api2_Status\":\"" + api2_status
					+ "\",\"api3_Status\":\"" + api3_status + "\",\"api4_Status\":\"" + api4_status
					+ "\",\"api5_Status\":\"" + api5_status + "\" ,\"statusCode\":\"" + statusCode + "\"}";

			inMessage.setHeader(Exchange.CONTENT_TYPE, "application/json");
			MessageContentsList req = new MessageContentsList();
			req.add(tentResponse);
			//System.out.println("bodyPara" + req);
			inMessage.setBody(req);

		} catch (Exception e) {
			log.error("Exception in process()", e);
		}

	}

	public void gstIN(Exchange exchange) throws Exception {
		try {
			Message inMessage = exchange.getIn();
			HashMap<String, String> map1 = new HashMap<>();
			map1 = (HashMap<String, String>) inMessage.getHeader("gstINBody");

			map1.remove("mbr");
			map1.remove("nba");
			//map1.remove("adadr");

			//System.out.println("MAP FOr GSTIN:" + map1);

			inMessage.setBody(map1);

		} catch (Exception e) {
			// TODO: handle exception
		}

	}

}