package org.tml.crm;

public class Pradr {

	String em;
	String adr;
	String addr;
	String mb;
	String ntr;
	public String getEm() {
		return em;
	}
	public void setEm(String em) {
		this.em = em;
	}
	public String getAdr() {
		return adr;
	}
	public void setAdr(String adr) {
		this.adr = adr;
	}
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
	public String getMb() {
		return mb;
	}
	public void setMb(String mb) {
		this.mb = mb;
	}
	public String getNtr() {
		return ntr;
	}
	public void setNtr(String ntr) {
		this.ntr = ntr;
	}
	
	
}
