package org.tml.crm;


import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

@XmlType(name = "checkResponse", propOrder = {
	    "status","name","canFlag",
	    "rc_body_type_desc","rc_chasi_no","rc_color","rc_cubic_cap","rc_eng_no","rc_f_name","rc_financer","rc_fit_upto","rc_fuel_desc"
	})
public class KYCOutput {

	String status;
	String name;
	String canFlag;
	String rc_body_type_desc;
	String rc_chasi_no;
	String rc_color;
	String rc_cubic_cap;
	String rc_eng_no;
	String rc_f_name;
	String rc_financer;
	String rc_fit_upto;
	String rc_fuel_desc;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCanFlag() {
		return canFlag;
	}

	public void setCanFlag(String canFlag) {
		this.canFlag = canFlag;
	}

	public String getRc_body_type_desc() {
		return rc_body_type_desc;
	}

	public void setRc_body_type_desc(String rc_body_type_desc) {
		this.rc_body_type_desc = rc_body_type_desc;
	}

	public String getRc_chasi_no() {
		return rc_chasi_no;
	}

	public void setRc_chasi_no(String rc_chasi_no) {
		this.rc_chasi_no = rc_chasi_no;
	}

	public String getRc_color() {
		return rc_color;
	}

	public void setRc_color(String rc_color) {
		this.rc_color = rc_color;
	}

	public String getRc_cubic_cap() {
		return rc_cubic_cap;
	}

	public void setRc_cubic_cap(String rc_cubic_cap) {
		this.rc_cubic_cap = rc_cubic_cap;
	}

	public String getRc_eng_no() {
		return rc_eng_no;
	}

	public void setRc_eng_no(String rc_eng_no) {
		this.rc_eng_no = rc_eng_no;
	}

	public String getRc_f_name() {
		return rc_f_name;
	}

	public void setRc_f_name(String rc_f_name) {
		this.rc_f_name = rc_f_name;
	}

	public String getRc_financer() {
		return rc_financer;
	}

	public void setRc_financer(String rc_financer) {
		this.rc_financer = rc_financer;
	}

	public String getRc_fit_upto() {
		return rc_fit_upto;
	}

	public void setRc_fit_upto(String rc_fit_upto) {
		this.rc_fit_upto = rc_fit_upto;
	}

	public String getRc_fuel_desc() {
		return rc_fuel_desc;
	}

	public void setRc_fuel_desc(String rc_fuel_desc) {
		this.rc_fuel_desc = rc_fuel_desc;
	}

	
}
