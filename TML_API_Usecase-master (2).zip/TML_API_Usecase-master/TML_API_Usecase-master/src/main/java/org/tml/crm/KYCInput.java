package org.tml.crm;


import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import java.sql.Date;

import javax.xml.bind.annotation.XmlAccessType;

@XmlAccessorType( XmlAccessType.FIELD )
@XmlType(name = "Check", propOrder = {
	    "pDOC_TYPE",
	    "pROW_ID",
	    "pCONSENT",
	    "pDOCUMENT_NO",
	    "pFULL_NAME",
	    "pDOB",
	    "pSERVICE_PROVIDER",
	    "pMOBILE_NO",
	    "pOTP",
	    "pLOGIN_ID",
		"pState",
		"pDOI",
		"pFileNo",
		"pNameMatchFlag"
	})
public class KYCInput {

	
	/*@XmlElement(required = true)
	int messageId;*/
	String pDOC_TYPE;
	String pROW_ID;
	String pCONSENT;
	String pDOCUMENT_NO;
	String pFULL_NAME;
	String pDOB;
	String pSERVICE_PROVIDER;
	
	String pMOBILE_NO;
	String pOTP;
	String pLOGIN_ID;
	String pState;
	String pDOI;
	String pFileNo;
	
	String pNameMatchFlag;
	/*@XmlElement(required = true)
	String messageText;*/
	
	public String getpDOC_TYPE() {
		return pDOC_TYPE;
	}
	public void setpDOC_TYPE(String pDOC_TYPE) {
		this.pDOC_TYPE = pDOC_TYPE;
	}
	public String getpROW_ID() {
		return pROW_ID;
	}
	public void setpROW_ID(String pROW_ID) {
		this.pROW_ID = pROW_ID;
	}
	public String getpCONSENT() {
		return pCONSENT;
	}
	public void setpCONSENT(String pCONSENT) {
		this.pCONSENT = pCONSENT;
	}
	public String getpDOCUMENT_NO() {
		return pDOCUMENT_NO;
	}
	public void setpDOCUMENT_NO(String pDOCUMENT_NO) {
		this.pDOCUMENT_NO = pDOCUMENT_NO;
	}
	public String getpFULL_NAME() {
		return pFULL_NAME;
	}
	public void setpFULL_NAME(String pFULL_NAME) {
		this.pFULL_NAME = pFULL_NAME;
	}
	public String getpDOB() {
		return pDOB;
	}
	public void setpDOB(String pDOB) {
		this.pDOB = pDOB;
	}
	public String getpSERVICE_PROVIDER() {
		return pSERVICE_PROVIDER;
	}
	public void setpSERVICE_PROVIDER(String pSERVICE_PROVIDER) {
		this.pSERVICE_PROVIDER = pSERVICE_PROVIDER;
	}
	public String getpMOBILE_NO() {
		return pMOBILE_NO;
	}
	public void setpMOBILE_NO(String pMOBILE_NO) {
		this.pMOBILE_NO = pMOBILE_NO;
	}
	public String getpOTP() {
		return pOTP;
	}
	public void setpOTP(String pOTP) {
		this.pOTP = pOTP;
	}
	public String getpLOGIN_ID() {
		return pLOGIN_ID;
	}
	public void setpLOGIN_ID(String pLOGIN_ID) {
		this.pLOGIN_ID = pLOGIN_ID;
	}
	public String getpState() {
		return pState;
	}
	public void setpState(String pState) {
		this.pState = pState;
	}
	public String getpDOI() {
		return pDOI;
	}
	public void setpDOI(String pDOI) {
		this.pDOI = pDOI;
	}
	public String getpFileNo() {
		return pFileNo;
	}
	public void setpFileNo(String pFileNo) {
		this.pFileNo = pFileNo;
	}
	
	public String getpNameMatchFlag() {
		return pNameMatchFlag;
	}
	public void setpNameMatchFlag(String pNameMatchFlag) {
		this.pNameMatchFlag = pNameMatchFlag;
	}
	
}
