package org.tml.crm;


import javax.jws.WebMethod;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.ws.RequestWrapper;
import javax.xml.ws.ResponseWrapper;

import org.tml.crm.*;
@WebService(targetNamespace = "http://org.tml.crm/")
public interface KYCService {

	
	 @WebMethod
	    @RequestWrapper(localName = "Check", targetNamespace = "http://org.tml.crm/", className = "org.tml.crm.KYCInput")
	    @ResponseWrapper(localName = "checkResponse", targetNamespace = "http://org.tml.crm/", className = "org.tml.crm.KYCOutput")
	    @WebResult(name = "status", targetNamespace = "")
	//	public KYCOutput Check(KYCInput input);
	 
	 public KYCOutput Check(KYCOutput input);
}
