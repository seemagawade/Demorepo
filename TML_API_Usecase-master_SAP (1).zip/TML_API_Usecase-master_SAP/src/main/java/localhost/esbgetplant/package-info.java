@javax.xml.bind.annotation.XmlSchema(namespace = "http://localhost/esbgetPlant/")
package localhost.esbgetplant;
