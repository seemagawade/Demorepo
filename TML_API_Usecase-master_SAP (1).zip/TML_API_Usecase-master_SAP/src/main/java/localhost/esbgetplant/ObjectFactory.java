
package localhost.esbgetplant;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the localhost.esbgetplant package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: localhost.esbgetplant
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link GetPlantOrder }
     * 
     */
    public GetPlantOrder createGetPlantOrder() {
        return new GetPlantOrder();
    }

    /**
     * Create an instance of {@link GetPlantOrderResponse }
     * 
     */
    public GetPlantOrderResponse createGetPlantOrderResponse() {
        return new GetPlantOrderResponse();
    }

    /**
     * Create an instance of {@link GetPLantT }
     * 
     */
    public GetPLantT createGetPLantT() {
        return new GetPLantT();
    }

    /**
     * Create an instance of {@link GetPLant }
     * 
     */
    public GetPLant createGetPLant() {
        return new GetPLant();
    }

}
