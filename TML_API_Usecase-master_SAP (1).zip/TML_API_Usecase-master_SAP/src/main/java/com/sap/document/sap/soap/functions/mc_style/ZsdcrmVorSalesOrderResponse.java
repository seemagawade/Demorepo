
package com.sap.document.sap.soap.functions.mc_style;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ItFinal" type="{urn:sap-com:document:sap:soap:functions:mc-style}ZsdcrmVorOrderT"/&gt;
 *         &lt;element name="VMsg" type="{urn:sap-com:document:sap:rfc:functions}char50"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "itFinal",
    "vMsg"
})
@XmlRootElement(name = "ZsdcrmVorSalesOrderResponse")
public class ZsdcrmVorSalesOrderResponse {

    @XmlElement(name = "ItFinal", required = true)
    protected ZsdcrmVorOrderT itFinal;
    @XmlElement(name = "VMsg", required = true)
    protected String vMsg;

    /**
     * Gets the value of the itFinal property.
     * 
     * @return
     *     possible object is
     *     {@link ZsdcrmVorOrderT }
     *     
     */
    public ZsdcrmVorOrderT getItFinal() {
        return itFinal;
    }

    /**
     * Sets the value of the itFinal property.
     * 
     * @param value
     *     allowed object is
     *     {@link ZsdcrmVorOrderT }
     *     
     */
    public void setItFinal(ZsdcrmVorOrderT value) {
        this.itFinal = value;
    }

    /**
     * Gets the value of the vMsg property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVMsg() {
        return vMsg;
    }

    /**
     * Sets the value of the vMsg property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVMsg(String value) {
        this.vMsg = value;
    }

}
