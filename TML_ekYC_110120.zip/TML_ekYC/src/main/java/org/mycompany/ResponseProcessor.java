package org.mycompany;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Base64;
import java.util.HashMap;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.Processor;
import org.apache.camel.component.cxf.common.message.CxfConstants;
import org.apache.cxf.message.MessageContentsList;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.restlet.util.Series;

import com.fasterxml.jackson.databind.ObjectMapper;

public class ResponseProcessor implements Processor {

	Logger log = Logger.getLogger(ResponseProcessor.class);
	
	
	
	/*public void combineJson (Exchange exchange) throws Exception{
		
		Message inMessage = exchange.getIn();		
		JSONObject rcBody = (JSONObject) inMessage.getHeader("rcResponseBody");
		ObjectMapper mapper = new ObjectMapper();
		
		mapper.w
		
		//System.out.println("Json 1: " + rcBody);
		
		JSONObject merger = new JSONObject(inMessage.getHeader("rcResponseBody"));
		
		
	System.out.println("Json 1: " + merger);
	inMessage.setBody(merger);
	
		try {
			
			merger = new JSONObject(rcBody);
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		
	}*/

	@Override
	public void process(Exchange exchange) throws Exception {
		try {
			Message inMessage = exchange.getIn();	
			
			String reqId = (String) inMessage.getHeader("requestId",String.class);
			String statusCode = (String) inMessage.getHeader("statusCode",String.class);			
			
			HashMap<String, String> map1 = new HashMap<>();
			 map1 = (HashMap<String, String>) inMessage.getHeader("rcResponseBody");
			 
			 HashMap<String, String> map2 = new HashMap<>();
			 map2 = (HashMap<String, String>) inMessage.getHeader("resultscore");
			
			System.out.println("rcBody : " + map2);
			
			map1.putAll(map2);
			
			System.out.println("Combine Body : " + map1);
			
			ObjectMapper objectMapper = new ObjectMapper();
			
			String jsonString = objectMapper.writeValueAsString(map1);
			
			System.out.println("JsonSTring : " + jsonString);
			
			String tentResponse = "{\"requestId\":\"" + reqId + "\",\"result\":" + jsonString + ", \"statusCode\":\"" + statusCode + "\"}";
			
			inMessage.setHeader(Exchange.CONTENT_TYPE, "application/json");
			MessageContentsList req = new MessageContentsList();
			req.add(tentResponse);
			System.out.println("bodyPara"+req);
			inMessage.setBody(req);
		} catch (Exception e) {
			log.error("Exception in process()", e);
		}
	}

}