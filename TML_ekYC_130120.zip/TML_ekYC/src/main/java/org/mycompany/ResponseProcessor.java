package org.mycompany;

import java.io.ByteArrayOutputStream;


import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPMessage;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.Processor;
import org.apache.camel.component.cxf.common.message.CxfConstants;
import org.apache.cxf.message.MessageContentsList;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.restlet.util.Series;

import org.apache.camel.component.cxf.CxfPayload;
import org.apache.cxf.binding.soap.SoapHeader;
import org.w3c.dom.Document;
import org.apache.camel.converter.jaxp.XmlConverter;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tml.crm.Foo;

public class ResponseProcessor implements Processor {

	Logger log = Logger.getLogger(ResponseProcessor.class);

	@Override
	public void process(Exchange exchange) throws Exception {
		try {
			Message inMessage = exchange.getIn();	
			
		
			
			String reqId = (String) inMessage.getHeader("requestId",String.class);
			String statusCode = (String) inMessage.getHeader("statusCode",String.class);	
			String jsonString = null;
			String tentResponse = null;

			if(statusCode.equals("101")) {
			
			HashMap<String, String> map1 = new HashMap<>();
			 map1 = (HashMap<String, String>) inMessage.getHeader("responseBody");
			 
			 HashMap<String, String> map2 = new HashMap<>();
			 map2 = (HashMap<String, String>) inMessage.getHeader("resultscore");
			
			System.out.println("rcBody : " + map2);
			
			map1.putAll(map2);
			
			System.out.println("Combine Body : " + map1);
			
			ObjectMapper objectMapper = new ObjectMapper();
			
			jsonString = objectMapper.writeValueAsString(map1);
			
			System.out.println("JsonSTring : " + jsonString);
			
			 tentResponse = "{\"requestId\":\"" + reqId + "\",\"result\":" + jsonString + ", \"statusCode\":\"" + statusCode + "\"}";
			
			}
			else {
				
				jsonString  = (String) inMessage.getHeader("responseBody",String.class);
				
				 tentResponse = "{\"requestId\":\"" + reqId + "\",\"result\":" + jsonString + ", \"statusCode\":\"" + statusCode + "\"}";
			}
			
			
			
			
			inMessage.setHeader(Exchange.CONTENT_TYPE, "application/json");
			MessageContentsList req = new MessageContentsList();
			req.add(tentResponse);
			System.out.println("bodyPara"+req);
			inMessage.setBody(req);
			
			
			
			
			
		} catch (Exception e) {
			log.error("Exception in process()", e);
		}
	
	}
	
	
	public  static void setXML(Exchange exchange) throws Exception {
		
		Message inMessage = exchange.getIn();
		String reqId = (String) inMessage.getBody(String.class);
		

	 MessageFactory mf = MessageFactory.newInstance();
	    SOAPMessage message = mf.createMessage();
	    SOAPBody body = message.getSOAPBody();

	    Foo foo = new Foo();
	    foo.setBar(reqId);

	    JAXBContext jc = JAXBContext.newInstance(Foo.class);
	    Marshaller marshaller = jc.createMarshaller();
	    marshaller.marshal(foo, body);

	    message.saveChanges();
	    message.writeTo(System.out);

	    
	  /*  MessageContentsList req = new MessageContentsList();
		req.add(marshaller);
		System.out.println("bodyPara"+marshaller);*/
		inMessage.setBody(marshaller);
		
	
	}

}