package com.tml.crm;

public class ContactedObj {

}
