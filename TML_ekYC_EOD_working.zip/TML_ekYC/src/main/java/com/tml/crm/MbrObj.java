package com.tml.crm;

public class MbrObj {

}
